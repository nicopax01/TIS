<?php
session_start();
require_once 'Controladores/ProductoController.php';
include 'header.php';
$categoriaSeleccionada = isset($_GET['categoria']) ? $_GET['categoria'] : 'default'; // Ajusta según sea necesario

$controlador = new ProductoController();
$controlador->mostrarProductosPorCategoria($categoriaSeleccionada);
include 'footer.php';
?>
