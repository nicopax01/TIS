<?php
session_start();

// Asegúrate de que el usuario esté autenticado
if (!isset($_SESSION['usuario']) || !isset($_SESSION['usuario']['rut'])) {
    // Redirigir al usuario a la página de inicio de sesión o mostrar un mensaje
    echo "Por favor, inicie sesión para ver sus pedidos.";
    exit;
}

require_once __DIR__ . '../Controladores/pedidoController.php';
require_once __DIR__ . '../config/conexion.php';
include 'header.php';

// Crear una instancia del controlador
$controller = new PedidoController();

// Mostrar los pedidos del usuario
$controller->verPedidosUsuario();
//include 'footer.php';
?>
