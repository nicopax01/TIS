<?php
session_start();
require_once 'config/conexion.php';
require_once 'Modelos/carritoModel.php';
require_once 'Controladores/carritoController.php';

$idProducto = $_GET['id_producto']; // Obtén el id_producto de la URL

// Incluye tus archivos y crea una instancia de CarritoModel si es necesario

if (isset($idProducto)) {
    $idCarrito = $_SESSION['id_carrito']; // Obtén el id_carrito de la sesión

    // Crea una instancia de CarritoModel
    $carritoModel = new CarritoModel();

    // Llama a la función para eliminar el producto del carrito
    $resultado = $carritoModel->eliminarProductoDelCarrito($idProducto, $idCarrito);

    if ($resultado) {
        // Redirige de regreso a la página del carrito o muestra un mensaje de éxito
        header("Location: carrito.php");
        exit(); // Asegúrate de detener la ejecución del script después de la redirección
    } else {
        // Muestra un mensaje de error si la eliminación falla
        echo "Error al eliminar el producto del carrito.";
    }
}
