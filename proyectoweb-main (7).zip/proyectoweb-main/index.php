<?php
session_start();
include 'config/conexion.php';
require_once 'Controladores/ProductoController.php';

include 'header.php';


?>
<!-- header -->
<header id="header" class="vh-100 carousel slide" data-bs-ride="carousel" style="padding-top: 104px;">
    <div class="container h-100 d-flex align-items-center carousel-inner">
        <div class="text-center carousel-item active">
            <h2 class="text-capitalize text-white">Encuentra tus productos</h2>
            <h1 class="text-uppercase py-2 fw-bold text-white">Catálogo</h1>
            <a href="catalogo.php" class="btn mt-3 text-uppercase">Ir</a>
        </div>
        <div class="text-center carousel-item">
            <h2 class="text-capitalize text-white">Descubre un poco más sobre Girasol</h2>
            <h1 class="text-uppercase py-2 fw-bold text-white">Sobre nosotros</h1>
            <a href="index.php#about" class="btn mt-3 text-uppercase">Ir</a>
        </div>
    </div>

    <button class="carousel-control-prev" type="button" data-bs-target="#header" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#header" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
    </button>
</header>

<!-- end of header -->

<!-- end of header -->



<?php


$controlador = new ProductoController();
$controlador->mostrarProductosDestacados();


?>
<!-- about us -->
<section id="about" class="py-5">
        <div class="container">
            <div class="row gy-lg-5 align-items-center">
                <div class="col-lg-6 order-lg-1 text-center text-lg-start">
                    <div class="title pt-3 pb-5">
                        <h2 class="position-relative d-inline-block ms-4">Sobre Girasol</h2>
                    </div>
                    <style>
                        .lead.text-muted {
                            text-align: justify;
                        }
                    </style>

                    <p class="lead text-muted">
                        <br>Misión: </br>
                        Ofrecer una amplia gama de regalos, dulces y abarrotes de alta calidad, brindando a nuestros clientes una experiencia de compra conveniente y satisfactoria. Buscamos ser el lugar preferido para encontrar productos únicos y deliciosos, satisfaciendo las necesidades de todos los que nos visitan.
                    </p>
                    <p class="lead text-muted">
                        <br>Visión: </br>
                        En Bazar Girasol, aspiramos a convertirnos en el destino principal para aquellos que buscan regalos especiales, golosinas deliciosas y abarrotes esenciales. Nos esforzamos por mantener una selección diversa y atractiva, combinada con un servicio amable y atento. Nuestra visión es crear un ambiente acogedor donde nuestros clientes se sientan inspirados y emocionados al explorar nuestras ofertas, dejando con sonrisas en sus rostros y deseos de regresar.
                    </p>

                </div>
                <div class="col-lg-6 order-lg-0">
                    <img src="images2/local.jpg" alt="" class="img-fluid">
                </div>
            </div>
        </div>
    </section>
    <!-- end of about us -->
    
<?php include 'footer.php'; ?>   