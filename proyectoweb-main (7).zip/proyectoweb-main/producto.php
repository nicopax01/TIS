<?php
session_start();
require_once 'Controladores/ProductoController.php';
include 'header.php';
if (isset($_GET['nombre'])) {
    $nombreProducto = htmlspecialchars($_GET['nombre']);
    $controlador = new ProductoController();
    $controlador->mostrarDetalleProducto($nombreProducto);
} else {
    echo 'Error: Nombre de producto no especificado';
}
include 'footer.php';
?>