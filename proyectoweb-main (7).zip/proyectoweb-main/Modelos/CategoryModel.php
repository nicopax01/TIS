<?php

require_once '../config/conexion.php';

// Modelos/CategoryModel.php

class CategoryModel {
    public function getAllCategories() {
        $dbConnection = conectarBD();
        $query = "SELECT id_categoria, nombre, descripcion, fecha_creacion FROM categoria ORDER BY nombre";
        $result = pg_query($dbConnection, $query);
        return $result ? pg_fetch_all($result) : [];
    }

    public function createCategory($nombre, $descripcion) {
        $dbConnection = conectarBD();
        $fecha_creacion = date('Y-m-d'); // Fecha actual
    
        // Genera un ID alfanumérico aleatorio de hasta 8 caracteres en mayúsculas.
        $id_categoria = '';
        for ($i = 0; $i < 8; $i++) {
            $id_categoria .= chr(rand(65, 90)); // Genera un caracter aleatorio entre 'A' (65) y 'Z' (90)
        }
    
        $query = "INSERT INTO categoria (id_categoria, nombre, descripcion, fecha_creacion) VALUES ($1, $2, $3, $4)";
        $result = pg_query_params($dbConnection, $query, [$id_categoria, $nombre, $descripcion, $fecha_creacion]);
        return $result && pg_affected_rows($result) > 0;
    }

    public function getCategory($id_categoria) {
        $dbConnection = conectarBD();
        $query = "SELECT id_categoria, nombre, descripcion, fecha_creacion FROM categoria WHERE id_categoria = $1";
        $result = pg_query_params($dbConnection, $query, [$id_categoria]);
        return $result ? pg_fetch_assoc($result) : false;
    }

    public function updateCategory($id_categoria, $nombre, $descripcion) {
        $dbConnection = conectarBD();
        $query = "UPDATE categoria SET nombre = $1, descripcion = $2 WHERE id_categoria = $3";
        $result = pg_query_params($dbConnection, $query, [$nombre, $descripcion, $id_categoria]);
        return $result && pg_affected_rows($result) > 0;
    }

    public function deleteCategory($id_categoria) {
        $dbConnection = conectarBD();
    
        // Verifica primero si hay productos asociados a esta categoría
        $checkQuery = "SELECT COUNT(*) FROM producto WHERE categoria_id_categoria = $1";
        $checkResult = pg_query_params($dbConnection, $checkQuery, [$id_categoria]);
        $count = pg_fetch_result($checkResult, 0);
    
        if ($count > 0) {
            // Hay productos asociados a la categoría, maneja esta situación de acuerdo a tu lógica de negocio
            return false;
        }
    
        // Si no hay productos asociados, procede a eliminar la categoría
        $query = "DELETE FROM categoria WHERE id_categoria = $1";
        $result = pg_query_params($dbConnection, $query, [$id_categoria]);
    
        return $result && pg_affected_rows($result) > 0;
    }
}


