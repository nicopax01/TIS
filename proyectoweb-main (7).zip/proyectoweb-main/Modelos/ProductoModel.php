<?php
require_once __DIR__ . '/../config/conexion.php';

class ProductoModel {
    


    public function listarProductos() {
        $conn = conectarBD();
        $query = 'SELECT * FROM producto'; // Asume que tu tabla se llama 'productos'
        $result = pg_query($conn, $query);

        if (!$result) {
            // Manejar error en la consulta
            die("Error en la consulta SQL: " . pg_last_error());
        }

        $productos = pg_fetch_all($result);
        pg_close($conn);

        return $productos;
    }

    public function verDetalle($nombreProducto) {
        $conn = conectarBD();
        $query = "SELECT nombre, precio, imagen, stock_critico, descripcion, categoria, id_producto FROM producto WHERE nombre = $1";
        $result = pg_query_params($conn, $query, array($nombreProducto));

        if (!$result) {
            die("Error en la consulta SQL: " . pg_last_error());
        }

        $producto = pg_fetch_assoc($result);
        pg_close($conn);

        return $producto;
    }

    public function listarPorCategoria($categoria) {
        $conn = conectarBD();
        $query = 'SELECT * FROM producto WHERE categoria = $1';
        $result = pg_query_params($conn, $query, array($categoria));

        if (!$result) {
            die("Error en la consulta SQL: " . pg_last_error());
        }

        $productos = pg_fetch_all($result);
        pg_close($conn);

        return $productos;
    }

    public function obtenerProductos() {
        $conn = conectarBD(); // Asegúrate de que esta función esté definida y accesible
        $sql = "SELECT nombre, precio, categoria, imagen, id_producto FROM producto";
        $result = pg_query($conn, $sql);
        return pg_fetch_all($result);
    }


    public function buscarPorNombre($terminoBusqueda) {
        $conn = conectarBD();
        $query = "SELECT id_producto, nombre, precio, imagen FROM producto WHERE nombre ILIKE $1";
        $result = pg_query_params($conn, $query, array("%" . $terminoBusqueda . "%"));

        $productos = array();
        if ($result) {
            while ($row = pg_fetch_assoc($result)) {
                $productos[] = $row;
            }
        }

        pg_close($conn);
        return $productos;
    }


}
?>
