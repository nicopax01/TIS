<?php
include_once '../config/conexion.php'; // Asegúrate de que la ruta es correcta.

class OrderModel {
    // Función para obtener todos los pedidos
    public function getAllOrders() {
        $dbConnection = conectarBD();
        $query = "SELECT * FROM pedido";
        $result = pg_query($dbConnection, $query);

        if ($result) {
            return pg_fetch_all($result);
        } else {
            // Manejo de error
            error_log("Error en la consulta SQL: " . pg_last_error($dbConnection));
            return [];
        }
    }

    // Función para obtener los detalles de un pedido específico
    public function getOrderDetails($orderId) {
        $dbConnection = conectarBD();
        $query = "SELECT * FROM pedido WHERE id_pedido = $1";
        $result = pg_query_params($dbConnection, $query, array($orderId));

        if ($result && pg_num_rows($result) == 1) {
            return pg_fetch_assoc($result);
        } else {
            return null;
        }
    }
    // Función para obtener los detalles de los productos de un pedido específico
    public function getOrderProductDetails($orderId) {
        $dbConnection = conectarBD();
        // Asegúrate de reemplazar 'cantidad' con el nombre real de la columna que tienes para la cantidad en la tabla 'pedido_producto'.
        $query = "SELECT prod.nombre, prod.precio
                  FROM pedido_producto pp
                  INNER JOIN producto prod ON pp.producto_id_producto = prod.id_producto
                  WHERE pp.pedido_id_pedido = $1";
        $result = pg_query_params($dbConnection, $query, array($orderId));
    
        if ($result) {
            return pg_fetch_all($result);
        } else {
            // Manejo de error
            error_log("Error en la consulta SQL: " . pg_last_error($dbConnection));
            return [];
        }
    }
    
    

    // Función para actualizar el estado de un pedido
    public function updateOrderStatus($orderId, $newStatus) {
        $dbConnection = conectarBD();
        $query = "UPDATE pedido SET estado = $1 WHERE id_pedido = $2";
        $result = pg_query_params($dbConnection, $query, array($newStatus, $orderId));

        return $result;
    }

    // Función para eliminar un pedido
    public function deleteOrder($orderId) {
        $dbConnection = conectarBD();
        $query = "DELETE FROM pedido WHERE id_pedido = $1";
        $result = pg_query_params($dbConnection, $query, array($orderId));

        return $result && pg_affected_rows($result) > 0;
    }

    // Aquí puedes agregar más métodos según sea necesario
}
?>
