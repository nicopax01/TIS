<?php
require_once __DIR__ . '/../config/conexion.php';

// CarritoModel.php
class CarritoModel {
    public function agregarProductoCarrito($idCarrito, $idProducto, $cantidad = 1) {
        $conn = conectarBD(); // Asumiendo que conectarBD() está accesible globalmente o importada

        // Primero, verifica si el producto ya está en el carrito
        $sql_check = "SELECT cantidad FROM carrito_detalle WHERE id_carrito = $1 AND id_producto = $2";
        $result_check = pg_query_params($conn, $sql_check, array($idCarrito, $idProducto));

        if ($result_check && pg_num_rows($result_check) > 0) {
            // Si el producto ya está en el carrito, actualiza la cantidad
            $row = pg_fetch_assoc($result_check);
            $nuevaCantidad = $row['cantidad'] + $cantidad;
            $sql_update = "UPDATE carrito_detalle SET cantidad = $1 WHERE id_carrito = $2 AND id_producto = $3";
            $result = pg_query_params($conn, $sql_update, array($nuevaCantidad, $idCarrito, $idProducto));
        } else {
            // Si el producto no está en el carrito, inserta un nuevo registro
            $sql_insert = "INSERT INTO carrito_detalle (id_carrito, id_producto, cantidad) VALUES ($1, $2, $3)";
            $result = pg_query_params($conn, $sql_insert, array($idCarrito, $idProducto, $cantidad));
        }

        if ($result) {
            return true; // Operación exitosa
        } else {
            // Manejo del error
            return false;
        }
    }

    public function obtenerDetallesCarrito($idCarrito) {
        $conn = conectarBD(); // Conexión a la base de datos

        $query = "SELECT 
                    carrito_detalle.id_carrito,
                    carrito_detalle.id_producto,
                    producto.nombre,
                    producto.precio,
                    carrito_detalle.cantidad
                  FROM 
                    carrito_detalle
                  INNER JOIN 
                    producto ON carrito_detalle.id_producto = producto.id_producto
                  WHERE 
                    carrito_detalle.id_carrito = $1";

        $result = pg_query_params($conn, $query, array($idCarrito));
        $detallesCarrito = array();

        if ($result) {
            while ($row = pg_fetch_assoc($result)) {
                array_push($detallesCarrito, $row);
            }
        }

        return $detallesCarrito;
    }
    
    public function eliminarProductoDelCarrito($idProducto, $idCarrito) {
        $conn = conectarBD(); // Asumiendo que conectarBD() está accesible globalmente o importada

        // Lógica para eliminar el producto del carrito en la base de datos
        $sql = "DELETE FROM carrito_detalle WHERE id_carrito = $1 AND id_producto = $2";
        $result = pg_query_params($conn, $sql, array($idCarrito, $idProducto));

        if ($result) {
            return true; // Operación exitosa
        } else {
            // Manejo del error
            return false;
        }
    }
    
    
}





?>
