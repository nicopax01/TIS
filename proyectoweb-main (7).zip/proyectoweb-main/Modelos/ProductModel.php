<?php
include_once '../config/conexion.php'; // Asegúrate de que la ruta es correcta.

class ProductModel
{
    // ... otras funciones ...

    public function getProductDetails($productId)
    {
        $dbConnection = conectarBD();
        $query = "SELECT * FROM producto WHERE id_producto = $1";
        $result = pg_query_params($dbConnection, $query, array($productId));

        if ($result && pg_num_rows($result) > 0) {
            return pg_fetch_assoc($result);
        } else {
            return null;
        }
    }
    public function getAllProducts()
    {
        $dbConnection = conectarBD();
        // Asegúrate de que los nombres de las tablas y columnas coincidan con tu base de datos real.
        $query = "SELECT prod.id_producto, prod.nombre, prod.precio, prod.stock_critico as stock_critico, prod.fecha, cat.nombre AS categoria_nombre
              FROM producto prod
              LEFT JOIN categoria cat ON prod.categoria_id_categoria = cat.id_categoria
              ORDER BY prod.nombre";
        $result = pg_query($dbConnection, $query);

        if ($result) {
            return pg_fetch_all($result);
        } else {
            error_log("Error en la consulta SQL: " . pg_last_error($dbConnection));
            return [];
        }
    }

    public function createProduct($productData)
    {
        $dbConnection = conectarBD();
        $query = "INSERT INTO producto (nombre, precio, categoria, descripcion, stock_critico, categoria_id_categoria, imagen, fecha) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)";
        $params = [
            $productData['nombre'],
            $productData['precio'],
            $productData['categoria'],
            $productData['descripcion'],
            $productData['stock_critico'],
            $productData['categoria_id_categoria'],
            $productData['imagen'], // Asegúrate de que la imagen tiene un valor o null si no se cargó ninguna imagen
            $productData['fecha'],
        ];

        $result = pg_query_params($dbConnection, $query, $params);
        return $result && pg_affected_rows($result) > 0;
    }



    public function updateProduct($productId, $productData)
    {
        $dbConnection = conectarBD();
        $query = "UPDATE producto SET 
                nombre = $1, 
                precio = $2, 
                categoria = $3, 
                imagen = $4, 
                fecha = $5, 
                descripcion = $6, 
                stock_critico = $7, 
                categoria_id_categoria = $8 
              WHERE id_producto = $9";

        $params = [
            $productData['nombre'],
            $productData['precio'],
            $productData['categoria'],
            $productData['imagen'],
            $productData['fecha'],
            $productData['descripcion'],
            $productData['stock_critico'],
            $productData['categoria_id_categoria'],
            $productId,
        ];
        $result = pg_query_params($dbConnection, $query, $params);
        return $result && pg_affected_rows($result) > 0;
    }

    public function deleteProduct($productId)
    {
        $dbConnection = conectarBD();
        $query = "DELETE FROM producto WHERE id_producto = $1";
        $result = pg_query_params($dbConnection, $query, array($productId));

        return $result && pg_affected_rows($result) > 0;
    }

    // ... otras funciones que necesites para crear productos ...
}
