<?php
require_once __DIR__ . '/../config/conexion.php';
class ClienteModel {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function registrarCliente($nombre, $apellido, $rut, $correo, $contrasena) {
        $contrasena_hash = password_hash($contrasena, PASSWORD_DEFAULT);
        
        // Inserción en la tabla usuario
        $queryUsuario = "INSERT INTO usuario (nombre, apellido, rut, correo, contraseña) VALUES ($1, $2, $3, $4, $5)";
        $resultUsuario = pg_query_params($this->conn, $queryUsuario, array($nombre, $apellido, $rut, $correo, $contrasena_hash));
    
        // Verifica si la inserción en usuario fue exitosa antes de continuar
        if ($resultUsuario) {
            // Inserción en la tabla cliente con el mismo rut
            $queryCliente = "INSERT INTO cliente (nombre, apellido, correo, contraseña, usuario_rut) VALUES ($1, $2, $3, $4, $5)";
            $resultCliente = pg_query_params($this->conn, $queryCliente, array($nombre, $apellido, $correo, $contrasena_hash, $rut));
            return $resultCliente;
        }
        
        return false;
    }
    
    private function generarIdCarrito() {
        $caracteres = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
        $longitud = 8;
        $idCarrito = '';
        for ($i = 0; $i < $longitud; $i++) {
            $idCarrito .= $caracteres[rand(0, strlen($caracteres) - 1)];
        }
        return $idCarrito;
    }
    
    public function asignarCarritoNuevo($usuarioRut) {
        $idCarrito = $this->generarIdCarrito();
        $query = "INSERT INTO carrito (id_carrito, total, cliente_usuario_rut) VALUES ($1, $2, $3)";
        $result = pg_query_params($this->conn, $query, array($idCarrito, 0, $usuarioRut));
        return $result;
    }

    public function obtenerCarritoPorUsuario($rutUsuario) {
        $conn = conectarBD();

        // Suponiendo que la tabla carrito tiene una columna cliente_usuario_rut
        $sql = "SELECT id_carrito FROM carrito WHERE cliente_usuario_rut = $1";
        $result = pg_query_params($conn, $sql, array($rutUsuario));

        if ($result && $row = pg_fetch_assoc($result)) {
            return $row['id_carrito']; // Retorna el id_carrito encontrado
        } else {
            return null; // No se encontró un carrito para el usuario
        }
    }
    


    public function verificarCredenciales($correo, $contrasena) {
        $query = "SELECT * FROM usuario WHERE correo = $1";
        $result = pg_query_params($this->conn, $query, array($correo));

        $_SESSION['rut'] = $usuarioRut;

        if ($result && $row = pg_fetch_assoc($result)) {
            if (password_verify($contrasena, $row['contraseña'])) {
                return $row; // Credenciales correctas, retorna la fila del usuario
            }
        }
        return false; // Credenciales incorrectas
    }

    public function esAdmin($rut) {
        $consultaAdmin = "SELECT * FROM admin WHERE usuario_rut = '$rut'";
        $resultadoAdmin = pg_query($this->conn, $consultaAdmin);
        return $resultadoAdmin && pg_num_rows($resultadoAdmin) > 0;
    }

}



?>