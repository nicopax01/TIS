<?php

include_once '../config/conexion.php'; 

class ReportModel {
    protected $dbConnection;

    public function __construct($dbConnection) {
        $this->dbConnection = $dbConnection;
    }

    public function getTotalClientes() {
        $query = "SELECT COUNT(*) AS total_clientes FROM cliente"; 
        $result = pg_query($this->dbConnection, $query);
        return pg_fetch_result($result, 0);
    }

    public function getVentasPorFecha($fechaInicio, $fechaFin) {
        // Si no se proporciona una fecha de inicio o una fecha de fin, usar una fecha por defecto
        $fechaInicio = $fechaInicio ?: '2000-01-01';
        $fechaFin = $fechaFin ?: '2099-12-31';
    
        $query = "SELECT DATE(fecha) AS fecha, SUM(total) AS total_ventas
                  FROM pedido
                  WHERE fecha >= $1 AND fecha <= $2
                  GROUP BY DATE(fecha)
                  ORDER BY fecha ASC";
        $result = pg_query_params($this->dbConnection, $query, array($fechaInicio, $fechaFin));
        if ($result === false) {
            throw new Exception('Error al ejecutar la consulta: ' . pg_last_error($this->dbConnection));
        }
        return pg_fetch_all($result);
    }

    public function getPedidosPorEstado() {
        $query = "SELECT estado, COUNT(*) AS cantidad
                  FROM pedido
                  GROUP BY estado
                  ORDER BY cantidad DESC";
        $result = pg_query($this->dbConnection, $query);
        return pg_fetch_all($result);
    }

    public function getIngresosPorPeriodo($startDate, $endDate) {
        $query = "SELECT DATE_TRUNC('month', fecha) AS mes, SUM(total) AS ingresos
                  FROM pedido
                  WHERE fecha BETWEEN $1 AND $2
                  GROUP BY mes
                  ORDER BY mes ASC";
        $result = pg_query_params($this->dbConnection, $query, array($startDate, $endDate));
        return pg_fetch_all($result);
    }

    public function getProductosMasVendidos() {
        $query = "SELECT p.nombre, SUM(cd.cantidad) AS unidades_vendidas, COUNT(*) AS num_ventas
                  FROM producto p
                  JOIN carrito_detalle cd ON p.id_producto = cd.id_producto
                  GROUP BY p.nombre
                  ORDER BY unidades_vendidas DESC
                  LIMIT 10";
        $result = pg_query($this->dbConnection, $query);
        return pg_fetch_all($result);
    }
    public function getVentasPorCategoria() {
        $query = "SELECT c.nombre as categoria, SUM(p.precio * cd.cantidad) as total_ventas
                  FROM categoria c
                  JOIN producto p ON c.id_categoria = p.categoria_id_categoria
                  JOIN carrito_detalle cd ON p.id_producto = cd.id_producto
                  GROUP BY c.nombre
                  ORDER BY total_ventas DESC";
        $result = pg_query($this->dbConnection, $query);
        return pg_fetch_all($result);
    }
    
    public function getClientesMasActivos() {
        $query = "SELECT u.nombre, COUNT(p.id_pedido) as num_pedidos
                  FROM usuario u
                  JOIN pedido p ON u.rut = p.cliente_usuario_rut
                  GROUP BY u.nombre
                  ORDER BY num_pedidos DESC
                  LIMIT 10";
        $result = pg_query($this->dbConnection, $query);
        
        return pg_fetch_all($result);
    }
    public function getTotalVentasPorMes() {
        // Asumiendo que 'fecha' y 'total' son columnas en tu tabla 'pedido'
        $query = "SELECT DATE_TRUNC('month', fecha) AS mes, SUM(total) AS total_ventas
                  FROM pedido
                  GROUP BY mes
                  ORDER BY mes";
        $result = pg_query($this->dbConnection, $query);
        return pg_fetch_all($result);
    }

    public function getProductosPopulares() {
        // Asumiendo que 'cantidad' es una columna en 'carrito_detalle' y se relaciona con 'producto'
        $query = "SELECT p.nombre, SUM(cd.cantidad) AS total_vendido
                  FROM producto p
                  JOIN carrito_detalle cd ON p.id_producto = cd.id_producto
                  GROUP BY p.nombre
                  ORDER BY total_vendido DESC
                  LIMIT 10";
        $result = pg_query($this->dbConnection, $query);
        return pg_fetch_all($result);
    }

    public function getClientesTop() {
        // Asumiendo que 'cliente_usuario_rut' en 'pedido' se relaciona con 'rut' en 'usuario'
        $query = "SELECT u.nombre, COUNT(p.id_pedido) AS num_pedidos
                  FROM usuario u
                  JOIN pedido p ON u.rut = p.cliente_usuario_rut
                  GROUP BY u.nombre
                  ORDER BY num_pedidos DESC
                  LIMIT 10";
        $result = pg_query($this->dbConnection, $query);
        return pg_fetch_all($result);
    }
    public function getPedidosPorCliente() {
        $query = "SELECT c.nombre, COUNT(p.id_pedido) AS num_pedidos
                  FROM cliente c
                  JOIN pedido p ON c.usuario_rut = p.cliente_usuario_rut
                  GROUP BY c.nombre
                  ORDER BY num_pedidos DESC";
        $result = pg_query($this->dbConnection, $query);
        if (!$result) {
            error_log('Consulta SQL fallida: ' . pg_last_error($this->dbConnection));
            return [];
        }
        return pg_fetch_all($result);
    }
    
    
    

    public function getTotalVentas() {
        // Suponiendo que 'total' es el monto del pedido
        $query = "SELECT SUM(total) AS total_ventas FROM pedido";
        $result = pg_query($this->dbConnection, $query);
        return pg_fetch_result($result, 0);
    }

    public function getVentasPorFechaEspecifica($fecha) {
        $query = "SELECT id_pedido, total, fecha, estado
                  FROM pedido
                  WHERE fecha::date = $1::date"; // Usar el operador de casting "::date" para comparar solo la parte de fecha
        $result = pg_query_params($this->dbConnection, $query, array($fecha));
        if (!$result) {
            error_log('Consulta SQL fallida: ' . pg_last_error($this->dbConnection));
            return [];
        }
        return pg_fetch_all($result);
    }
    public function getVentasPorMes($mesAnio) {
        $fechaInicio = $mesAnio . '-01'; // Primer día del mes
        $fechaFin = date('Y-m-t', strtotime($fechaInicio)); // Último día del mes
    
        $query = "SELECT id_pedido, total, fecha, estado
                  FROM pedido
                  WHERE fecha BETWEEN $1 AND $2
                  ORDER BY fecha ASC";
        $result = pg_query_params($this->dbConnection, $query, array($fechaInicio, $fechaFin));
        if (!$result) {
            error_log('Consulta SQL fallida: ' . pg_last_error($this->dbConnection));
            return [];
        }
        return pg_fetch_all($result);
    }
    public function getVentasTotalesPorMes() {
    $query = "SELECT DATE_TRUNC('month', fecha) AS mes, SUM(total) AS total_ventas
              FROM pedido
              GROUP BY mes
              ORDER BY mes ASC";
    $result = pg_query($this->dbConnection, $query);
    if (!$result) {
        error_log('Consulta SQL fallida: ' . pg_last_error($this->dbConnection));
        return [];
    }
    return pg_fetch_all($result);
}
    

    // Métodos adicionales para otros reportes...
}

?>
