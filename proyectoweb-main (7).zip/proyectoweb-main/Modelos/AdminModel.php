<?php
require_once '../config/conexion.php'; // Asegúrate de que la ruta es correcta.

class AdminModel {
    private $dbConnection;

    public function __construct() {
        // Utiliza la función de tu archivo conexion.php para conectar a la BD.
        $this->dbConnection = conectarBD();
    }

    public function validateAdmin($username, $password) {
        // Prepara la consulta SQL para verificar el nombre de usuario y contraseña.
        $query = "SELECT contraseña FROM admin WHERE nom_usuario = $1";
        $result = pg_query_params($this->dbConnection, $query, array($username));

        if ($result && pg_num_rows($result) == 1) {
            $row = pg_fetch_assoc($result);
            // Usa password_verify para comparar la contraseña ingresada con la hash de la BD.
            return password_verify($password, $row['contraseña']);
        } else {
            // Si no se encuentra el usuario o la contraseña no coincide, retorna falso.
            return false;
        }
    }
}

?>


