<?php
// PedidoModel.php
require_once __DIR__ . '/../config/conexion.php';

class PedidoModel {
    public function crearPedido($idPedido, $totalCarrito, $clienteUsuarioRut, $adminUsuarioRut) {
        $conn = conectarBD(); 
        $fechaActual = date('Y-m-d');
        $estado = 'pagado';

        $query = "INSERT INTO pedido (id_pedido, total, fecha, cliente_usuario_rut, admin_usuario_rut, estado) VALUES ($1, $2, $3, $4, $5, $6)";
        $result = pg_query_params($conn, $query, array($idPedido, $totalCarrito, $fechaActual, $clienteUsuarioRut, $adminUsuarioRut, $estado));

        pg_close($conn);
        return $result;
    }


    public function actualizarInventario($idProducto, $cantidadComprada) {
        $conn = conectarBD();

        $queryActualizarProducto = "UPDATE producto SET stock_critico = stock_critico - $1 WHERE id_producto = $2";
        $resultActualizar = pg_query_params($conn, $queryActualizarProducto, array($cantidadComprada, $idProducto));

        pg_close($conn);
        return $resultActualizar;
    }

    public function obtenerPedidosPorUsuario($clienteUsuarioRut) {
        $conn = conectarBD();
        $query = "SELECT * FROM pedido WHERE cliente_usuario_rut = $1";
        $result = pg_query_params($conn, $query, array($clienteUsuarioRut));

        $pedidos = array();
        if ($result) {
            while ($row = pg_fetch_assoc($result)) {
                $pedidos[] = $row;
            }
        }

        pg_close($conn);
        return $pedidos;
    }

    

    

    // ... otros métodos ...
}

?>