<!-- footer -->
<footer class="bg-dark py-5">
        <div class="container">
            <div class="row gy-lg-5 align-items-center">
                <div class="row text-white g-4">
                    <div class="col-md-6 col-lg-3">
                        <a class="text-uppercase text-decoration-none brand text-white" href="index.html">Girasol</a>
                        <p class="text-white text-muted mt-3">Por siempre, seremos tu mejor opción.</p>
                    </div>



                    <div class="col-md-6 col-lg-3">
                        <h5 class="fw-light mb-3">Contáctanos</h5>
                        <div class="d-flex justify-content-start align-items-start my-2 text-muted">
                            <span class="me-3">
                                <i class="fas fa-map-marked-alt"></i>
                            </span>
                            <span class="fw-light">
                                Cardenal José María Caro 2635, Local #100
                            </span>
                        </div>
                        <div class="d-flex justify-content-start align-items-start my-2 text-muted">
                            <span class="me-3">
                                <i class="fas fa-envelope"></i>
                            </span>
                            <span class="fw-light">
                                girasoliqq@gmail.com
                            </span>
                        </div>
                        <div class="d-flex justify-content-start align-items-start my-2 text-muted">
                            <span class="me-3">
                                <i class="fas fa-phone-alt"></i>
                            </span>
                            <span class="fw-light">
                                +56 9 79762703
                            </span>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-3">
                        <h5 class="fw-light mb-3">Síguenos</h5>
                        <div>
                            <ul class="list-unstyled d-flex">
                                <li>
                                    <a href="#" class="text-white text-decoration-none text-muted fs-4 me-4">
                                        <i class="fab fa-facebook-f"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="text-white text-decoration-none text-muted fs-4 me-4">
                                        <i class="fab fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="text-white text-decoration-none text-muted fs-4 me-4">
                                        <i class="fab fa-instagram"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="text-white text-decoration-none text-muted fs-4 me-4">
                                        <i class="fab fa-pinterest"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            </footer>
    <!-- end of footer -->






    <!-- jquery -->
    <script src="js/jquery-3.6.0.js"></script>
    <!-- isotope js -->
    <script src="https://unpkg.com/isotope-layout@3/dist/isotope.pkgd.js"></script>
    <!-- bootstrap js -->
    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
    <!-- custom js -->
    <script src="js/script.js"></script>