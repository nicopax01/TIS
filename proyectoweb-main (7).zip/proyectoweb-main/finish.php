<?php
    // graciasPorSuCompra.php
    include_once 'controladores/PedidoController.php';


session_start();

$pedidoController = new PedidoController();
$pedidoController->procesarCompra();

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gracias por tu compra</title>
    <link rel="stylesheet" href="css/finish.css"> <!-- Asegúrate de enlazar tu archivo CSS aquí -->
</head>
<body>
    <div class="checkmark-container">
        <div class="checkmark-circle">
            <svg class="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
                <circle class="checkmark-circle" cx="26" cy="26" r="25" fill="none"/>
                <path class="checkmark-check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
            </svg>
        </div>
        <h2>¡Gracias por tu compra!</h2>
        <p>Serás redirigido a la página principal en unos momentos...</p>
    </div>
    <script>
        setTimeout(function() {
            window.location.href = 'index.php'; 
        }, 7000);  //7000 milisegundos = 7 segundos
    </script>
</body>
</html>



