<?php

// Controladores/CategoriesController.php
// Controladores/CategoriesController.php

include_once '../Modelos/CategoryModel.php';

class CategoriesController {
    private $categoryModel;

    public function __construct() {
        $this->categoryModel = new CategoryModel();
    }

    public function listAllCategories() {
        return $this->categoryModel->getAllCategories();
    }

    public function createCategory($nombre, $descripcion) {
        return $this->categoryModel->createCategory($nombre, $descripcion);
    }

    public function getCategory($id_categoria) {
        return $this->categoryModel->getCategory($id_categoria);
    }

    public function updateCategory($id_categoria, $nombre, $descripcion) {
        return $this->categoryModel->updateCategory($id_categoria, $nombre, $descripcion);
    }

    public function deleteCategory($id_categoria) {
        return $this->categoryModel->deleteCategory($id_categoria);
    }
}

