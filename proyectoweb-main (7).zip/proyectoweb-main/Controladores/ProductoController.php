<?php
require_once __DIR__ . '/../Modelos/ProductoModel.php';
require_once __DIR__ . '/../Vistas/ProductoView.php';

class ProductoController {
    private $modelo;

    public function __construct() {
        $this->modelo = new ProductoModel();
        $this->vista = new ProductoView();
    }

    public function mostrarCatalogo() {
        $modelo = new ProductoModel();
        $productos = $modelo->listarProductos();

        $view = new ProductoView();
        $view->mostrarCatalogo($productos);
    }

    public function mostrarProductosPorCategoria($categoria) {
        $modelo = new ProductoModel();
        $productos = $modelo->listarPorCategoria($categoria);

        $view = new ProductoView();
        $view->mostrarProductosPorCategoria($productos, $categoria);
    }

    public function mostrarDetalleProducto($nombreProducto) {
        $modelo = new ProductoModel();
        $producto = $modelo->verDetalle($nombreProducto);

        $view = new ProductoView();
        $view->mostrarDetalleProducto($producto);
    }

    public function mostrarProductosDestacados() {
        $productos = $this->modelo->obtenerProductos();
        $this->vista->mostrarProductosDestacados($productos);
    }

    public function buscar() {
        $terminoBusqueda = isset($_GET['busqueda']) ? $_GET['busqueda'] : '';
        $productos = $this->modelo->buscarPorNombre($terminoBusqueda);
        return $productos; // Podemos devolver los productos y manejar la vista por separado
    }
}
?>



