<?php
include_once '../Modelos/ProductModel.php';

class ProductsController {
    private $productModel;

    public function __construct() {
        $this->productModel = new ProductModel();
    }
    public function listAllProducts() {
        return $this->productModel->getAllProducts();
    }

    public function createProduct($productData) {
        return $this->productModel->createProduct($productData);
    }

    public function getProductDetails($productId) {
        return $this->productModel->getProductDetails($productId);
    }

    public function updateProduct($productId, $productData) {
        return $this->productModel->updateProduct($productId, $productData);
    }

    public function deleteProduct($productId) {
        return $this->productModel->deleteProduct($productId);
    }
    
    
}

?>

