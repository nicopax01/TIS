<?php

// Asegúrate de que la ruta al archivo del modelo es correcta.
include_once '../Modelos/ReportModel.php'; 

class ReportController {
    private $reportModel;

    public function __construct($dbConnection) {
        // Crea una instancia del modelo con la conexión a la base de datos.
        $this->reportModel = new ReportModel($dbConnection);
    }

    public function getTotalClientes() {
        // Llama al método del modelo y devuelve su valor.
        return $this->reportModel->getTotalClientes();
    }

    public function getVentasPorFecha($fechaInicio, $fechaFin) {
        return $this->reportModel->getVentasPorFecha($fechaInicio, $fechaFin);
    }

    public function getPedidosPorEstado() {
        // Llama al método del modelo y devuelve su valor.
        return $this->reportModel->getPedidosPorEstado();
    }

    public function getIngresosPorPeriodo($startDate, $endDate) {
        // Llama al método del modelo con los parámetros de fecha y devuelve su valor.
        return $this->reportModel->getIngresosPorPeriodo($startDate, $endDate);
    }

    public function getProductosMasVendidos() {
        // Llama al método del modelo y devuelve su valor.
        return $this->reportModel->getProductosMasVendidos();
    }
    public function getVentasPorCategoria() {
        return $this->reportModel->getVentasPorCategoria();
    }
    
    
    public function getClientesMasActivos() {
        return $this->reportModel->getClientesMasActivos();
    }
    public function getTotalVentasPorMes() {
        return $this->reportModel->getTotalVentasPorMes();
    }

    public function getProductosPopulares() {
        return $this->reportModel->getProductosPopulares();
    }

    public function getClientesTop() {
        return $this->reportModel->getClientesTop();
    }
    public function getPedidosPorCliente() {
        return $this->reportModel->getPedidosPorCliente();
    }

    public function getTotalVentas() {
        return $this->reportModel->getTotalVentas();
    }

    public function getVentasPorFechaEspecifica($fecha) {
        return $this->reportModel->getVentasPorFechaEspecifica($fecha);
    }
    public function getVentasPorMes($mesAnio) {
        return $this->reportModel->getVentasPorMes($mesAnio);
    }
    public function getVentasTotalesPorMes() {
    return $this->reportModel->getVentasTotalesPorMes();
}
    
    
    
    

    // Puedes agregar más métodos para otros reportes que necesites.
}

?>
