<?php
require_once '../Modelos/AdminModel.php'; // Asegúrate de que la ruta es correcta.

session_start(); // Iniciar la sesión al principio del archivo.

class AdminController {
    private $model;

    public function __construct() {
        $this->model = new AdminModel();
    }

    public function login($username, $password) {
        // Verifica las credenciales del administrador
        if ($this->model->validateAdmin($username, $password)) {
            // Si las credenciales son correctas, establece la variable de sesión
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username'] = $username;
            // Redirige al dashboard del administrador
            header('Location: ../Vistas/AdminDashboard.php');
            exit();
        } else {
            // Si las credenciales son incorrectas, muestra un mensaje de error
            // Podría ser una buena práctica redirigir al login con un mensaje de error
            header('Location: ../Vistas/admin_login.php?error=invalid_credentials');
            exit();
        }
    }
}

// Manejo de la solicitud POST del formulario de inicio de sesión
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['username']) && isset($_POST['password'])) {
    $controller = new AdminController();
    $controller->login($_POST['username'], $_POST['password']);
}
?>


