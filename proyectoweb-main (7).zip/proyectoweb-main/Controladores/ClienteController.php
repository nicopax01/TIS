<?php
require_once __DIR__ . '/../Modelos/ClienteModel.php';
require_once __DIR__ . '/../Vistas/ClienteView.php';

class ClienteController {
    private $model;

    public function __construct($model) {
        $this->model = $model;
    }

    public function registrar() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = $_POST['nombre'];
            $apellido = $_POST['apellido'];
            $rut = $_POST['rut'];
            $correo = $_POST['correo'];
            $contrasena = $_POST['contrasena'];
    
            // Registrar cliente en la base de datos
            if ($this->model->registrarCliente($nombre, $apellido, $rut, $correo, $contrasena)) {
                // Si el cliente se registra exitosamente, asignarle un carrito
                if ($this->model->asignarCarritoNuevo($rut)) {
                    // Si el carrito se asigna exitosamente, establecer sesión y redirigir
                    $_SESSION['usuario'] = ['nombre' => $nombre, /* otros datos necesarios */];
                    header("Location: index.php");
                    exit();
                } else {
                    // Si ocurre un error al asignar el carrito
                    $_SESSION['error_message'] = "Error al asignar carrito.";
                    header("Location: /ProyectoWebTIS2/proyectoweb/pagina_de_error.html");
                    exit();
                }
            } else {
                // Si ocurre un error al registrar el cliente
                $_SESSION['error_message'] = "Error al insertar datos en la base de datos.";
                header("Location: /ProyectoWebTIS2/proyectoweb/pagina_de_error.html");
                exit();
            }
        }
    }
    


    public function autentificar() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $correo = $_POST['correo'];
            $contrasena = $_POST['contrasena'];

            if ($usuario = $this->model->verificarCredenciales($correo, $contrasena)) {
                session_start();
                $_SESSION['usuario'] = $usuario;
                $_SESSION['usuario_rut'] = $usuario['rut']; // Asegúrate de que 'rut' sea la clave correcta.

                $_SESSION['usuario']['esAdmin'] = $this->model->esAdmin($usuario['rut']);
                

                
                $idCarrito = $this->model->obtenerCarritoPorUsuario($usuario['rut']);
                if ($idCarrito) {
                    $_SESSION['id_carrito'] = $idCarrito;
                } else {
                    // Opcional: manejar la situación donde el usuario no tiene un carrito
                    // Esto podría incluir crear un nuevo carrito y asignar su ID
                }

                header("Location: index.php");
                exit();
            } else {
                header("Location: login.php?error=1"); // Redirige con un mensaje de error
                exit();
            }
        }
    }
}



?>