<?php
require_once __DIR__ . '/../Modelos/carritoModel.php';
require_once __DIR__ . '/../Vistas/carritoView.php';

class CarritoController {
    public function agregarAlCarrito() {
        $idProducto = $_POST['id_producto'];
        $idCarrito = $_SESSION['id_carrito'];
        $cantidad = 1; // Cantidad predeterminada

        $carritoModel = new CarritoModel();
        $resultado = $carritoModel->agregarProductoCarrito($idCarrito, $idProducto, $cantidad);

        if ($resultado) {
            // Redirigir o mostrar mensaje de éxito
        } else {
            // Mostrar mensaje de error
        }
    }

    public function mostrarDetallesCarrito() {
        $carritoModel = new CarritoModel();
        $idCarrito = $_SESSION['id_carrito'];
        $detallesCarrito = $carritoModel->obtenerDetallesCarrito($idCarrito);

        $carritoView = new CarritoView();
        $carritoView->mostrarDetallesCarrito($detallesCarrito);
    }

    public function eliminarProductoDelCarrito($idProducto, $idCarrito) {
    // Lógica para eliminar el producto del carrito en la base de datos
    $carritoModel = new CarritoModel();
    $resultado = $carritoModel->eliminarProducto($idCarrito, $idProducto);

    if ($resultado) {
        // Redirigir o mostrar un mensaje de éxito
        // Por ejemplo, puedes redirigir de nuevo a la página de detalles del carrito
        header("Location: carrito.php");
        exit(); // Importante salir del script después de la redirección
    } else {
        // Mostrar un mensaje de error
        echo "Error al eliminar el producto del carrito.";
    }
}

}
?>
