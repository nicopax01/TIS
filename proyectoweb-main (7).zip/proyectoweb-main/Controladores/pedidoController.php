<?php
require_once __DIR__ . '/../Modelos/pedidoModel.php';
require_once __DIR__ . '/../Modelos/carritoModel.php';
require_once __DIR__ . '/../Vistas/pedidoView.php';


class PedidoController {

    private $model;
    private $view;

    public function __construct() {
        $this->model = new PedidoModel();
        $this->view = new PedidoView();
    }

    public function procesarCompra() {
        $pedidoModel = new PedidoModel();
        $carritoModel = new CarritoModel(); // Asegúrate de tener acceso a CarritoModel
    
        $totalCarrito = isset($_SESSION['total_carrito']) ? $_SESSION['total_carrito'] : 0;
        $clienteUsuarioRut = isset($_SESSION['usuario']['rut']) ? $_SESSION['usuario']['rut'] : null;
        $adminUsuarioRut = $this->obtenerAdminUsuarioRut();
        $idPedido = $this->generarIdPedido(); // Función para generar un ID aleatorio
    
        // Obtener los detalles del carrito
        $idCarrito = $_SESSION['id_carrito'] ?? null;

        $detallesCarrito = $carritoModel->obtenerDetallesCarrito($idCarrito);
    
        // Iniciar transacción aquí si es posible
    
        $resultado = $pedidoModel->crearPedido($idPedido, $totalCarrito, $clienteUsuarioRut, $adminUsuarioRut);
    
        if ($resultado) {
            foreach ($detallesCarrito as $detalle) {
                $idProducto = $detalle['id_producto'];
                $cantidadComprada = $detalle['cantidad'];
    
                // Actualiza el inventario para cada producto en el carrito
                $pedidoModel->actualizarInventario($idProducto, $cantidadComprada);
            }
    
            // Confirmar transacción aquí si es posible
    
            //echo 'Gracias por su compra';
        } else {
            // Revertir transacción aquí si es posible
    
            echo 'Error al procesar la compra';
        }
    }
    

    private function obtenerAdminUsuarioRut() {
        // Establecer una conexión con la base de datos
        $conn = conectarBD(); // Asegúrate de que esta función esté definida y devuelva una conexión válida a la base de datos
    
        // Preparar y ejecutar la consulta
        // Asumiendo que la tabla se llama 'admin' y la columna del RUT es 'usuario_rut'
        $query = "SELECT usuario_rut FROM admin LIMIT 1";
        $result = pg_query($conn, $query);
    
        // Verificar si la consulta fue exitosa y si hay resultados
        if ($result && pg_num_rows($result) > 0) {
            $row = pg_fetch_assoc($result);
            return $row['usuario_rut'];
        } else {
            // Manejar el caso en que no se encontró el RUT del administrador o hubo un error en la consulta
            echo "No se encontró el RUT del administrador o error en la consulta: " . pg_last_error($conn);
            return null;
        }
    }
    

    private function generarIdPedido() {
        return substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 8);
    }

    public function verPedidosUsuario() {
        // Asegúrate de que el usuario esté autenticado y tenga un RUT asociado
        if (isset($_SESSION['usuario']['rut'])) {
            $clienteUsuarioRut = $_SESSION['usuario']['rut'];
            $pedidos = $this->model->obtenerPedidosPorUsuario($clienteUsuarioRut);

            // Llamar a la vista para mostrar los pedidos
            $this->view->mostrarPedidosUsuario($pedidos);
        } else {
            echo "Usuario no autenticado o RUT no disponible.";
        }
    }


    
}
