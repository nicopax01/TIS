
<?php
include_once '../Modelos/OrderModel.php';

class OrdersController {
    private $orderModel;

    public function __construct() {
        $this->orderModel = new OrderModel();
    }

    public function listAllOrders() {
        return $this->orderModel->getAllOrders();
    }

    public function getOrderDetails($orderId) {
        return $this->orderModel->getOrderDetails($orderId);
    }

    public function getOrderProductDetails($orderId) {
        return $this->orderModel->getOrderProductDetails($orderId);
    }

    public function updateOrderStatus($orderId, $newStatus) {
        return $this->orderModel->updateOrderStatus($orderId, $newStatus);
    }

    public function deleteOrder($orderId) {
        return $this->orderModel->deleteOrder($orderId);
    }
}
?>
