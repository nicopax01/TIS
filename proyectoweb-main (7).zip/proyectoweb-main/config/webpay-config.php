<?php
use Transbank\Webpay\WebpayPlus;
use Transbank\Webpay\WebpayPlus\Transaction;

require_once 'vendor/autoload.php';

// Configuración para ambiente de integración (cambia a producción cuando sea necesario)
WebpayPlus::configureForTesting();

return new Transaction();
?>
