<?php
function conectarBD() {
    $host = "magallanes.inf.unap.cl";
    $database = "murrutia";
    $user = "murrutia";
    $password = "Z5z65m2kAw";
    $port = "5432";

    $conn = pg_connect("host=$host dbname=$database user=$user password=$password port=$port");
    
    if (!$conn) {
        // Manejar el error de conexión
        die("Error de conexión a la base de datos: " . pg_last_error());
    }

    return $conn;
}
?>

