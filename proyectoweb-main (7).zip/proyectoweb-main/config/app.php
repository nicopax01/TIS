<?php
    const SERVERURL = "http://localhost/ProyectoWebTIS/";   
    const COMPANY="Ecommerce";
    const MONEDA="$";
    
    date_default_timezone_set("America/Santiago");
    
?>


