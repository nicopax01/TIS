<?php
$transaction = include('config/webpay-config.php');

session_start();

if (isset($_POST['totalCarrito'])) {
    $total = $_POST['totalCarrito']; // Valida y limpia esta entrada
    $buyOrder = strval(rand()); // Genera un número de orden único
    $sessionId = session_id(); // Obtiene el ID de la sesión actual
    $returnUrl = 'http://localhost/ProyectoWebTIS/response.php'; // URL de retorno

    $response = $transaction->create($buyOrder, $sessionId, $total, $returnUrl);
    

    // Almacena el token en la sesión para su uso posterior
    $_SESSION['token_ws'] = $response->getToken();

    // Redirige al formulario de pago de Webpay
    header('Location: ' . $response->getUrl() . '?token_ws=' . $response->getToken());
    exit;
}
?>
