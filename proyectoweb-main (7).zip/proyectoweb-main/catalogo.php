
<?php
session_start();
require_once 'Controladores/ProductoController.php';
include 'header.php';
$controlador = new ProductoController();
$controlador->mostrarCatalogo();
include 'footer.php';
?>
