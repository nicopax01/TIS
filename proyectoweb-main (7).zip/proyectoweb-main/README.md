# proyectoweb
Trabajo realizado por Matias Urrutia, Nicolás Villaroel y Joaquín Ávalos

Para hacer uso del proyecto se necesito alojar en un servidor, de manera local puedes utilizar xampp y apache
buscar la ubicación de la carpeta xampp en tu equipo y en la carpeta htdocs alojar el proyecto 
![image](https://github.com/joaquinavalos20/proyectoweb/assets/115676044/ad3df66b-d2c7-4a81-a996-ad0467f1e512)

para correr el proyecto basta con utilizar tu direccion local del proyecto utilizando http://localhost/seguido-de-tus-rutas
ej: http://localhost/ProyectoWebTIS/index.php

y muy importante cambiar este linea de codigo que se encuentra en pagar.php tambien por tu ruta para que los pagos se procesen correctamente 

![image](https://github.com/joaquinavalos20/proyectoweb/assets/115676044/6b7f73f6-ae07-4c06-97f8-4bbcf8604bb3)

con todo eso la pagina ya es totalmente funcional. Gracias

