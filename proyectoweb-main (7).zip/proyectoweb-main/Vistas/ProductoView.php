<?php
class ProductoView {
    public function mostrarCatalogo($productos) {
        echo '<br><br>';
        echo '<section id="collection" class="py-5">';
        echo '<div class="container">';
        echo '<div class="title text-center">';
        echo '<br><br>';
        echo '<h1>Catálogo</h1>';
        echo '</div>';
        echo '<div class="row g-10 collection-list mt-4 gx-0 gy-3">';

        foreach ($productos as $producto) {
            echo '<div class="col-md-6 col-lg-4 col-xl-3 p-2">';
            echo '<div class="collection-img position-relative">';
            echo '<img src="' . htmlspecialchars($producto["imagen"]) . '" class="w-100">';
            echo '</div>';
            echo '<div class="text-center">';
            echo '<p class="text-capitalize my-1">' . htmlspecialchars($producto["nombre"]) . '</p>';
            echo '<span class="fw-bold">$ ' . number_format($producto["precio"], 0, ',', '.') . ' </span>';
            echo '<div class="mt-3 d-flex justify-content-between">';
            echo '<form action="carrito.php" method="post">';
            echo '<input type="hidden" name="id_producto" value="' . $producto["id_producto"] . '">';
            echo '<input type="hidden" name="accion" value="agregarCarrito">';
            echo '<button type="submit" class="btn btn-primary">Añadir al carrito</button>';
            echo '</form>';
            echo '<a href="producto.php?nombre=' . urlencode($producto["nombre"]) . '" class="btn btn-primary">Ver Detalles</a>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }

        echo '</div>';
        echo '</div>';
        echo '</section>';
    }

    public function mostrarDetalleProducto($producto) {
        // Asegúrate de que el producto no sea null
        if ($producto) {
            echo '<br><br><section id="collection" class="py-5">';
            echo '<div class="container">';
            echo '<div class="row g-0">';
            echo '<div class="collection-list mt-4 row gx-0 gy-3">';

            // Muestra la información detallada del producto
            echo '<div class="product-container">';
            echo '<h1>' . htmlspecialchars($producto['nombre']) . '</h1>';
            echo '<img src="' . htmlspecialchars($producto["imagen"]) . '" class="w-50">';
            echo '<p>Categoría: ' . htmlspecialchars($producto['categoria']) . '</p>';
            echo '<p style="text-align: justify;">Descripción: ' . htmlspecialchars($producto['descripcion']) . '</p>';
            echo '<p>Precio: $' . number_format($producto["precio"], 0, ',', '.') . '</p>';
            echo '<p>Stock: ' . htmlspecialchars($producto['stock_critico']) . '</p>';
            echo '<div class="product-buttons">';
            echo '<form action="carrito.php" method="post">';
            echo '<input type="hidden" name="id_producto" value="' . $producto["id_producto"] . '">';
            echo '<input type="hidden" name="accion" value="agregarCarrito">';
            echo '<form action="carrito.php" method="post">';
            echo '<input type="hidden" name="id_producto" value="' . $producto["id_producto"] . '">';
            echo '<input type="hidden" name="accion" value="agregarCarrito">';
            echo '<button type="submit" class="btn btn-primary">Añadir al carrito</button>';
            echo '</form>';
            echo '</form>';
            echo '<a href="categoria.php?categoria=' . urlencode($producto['categoria']) . '" class="btn btn-primary">Volver a la lista</a>';
            echo '</div>';
            echo '</div>';

            echo '</div></div></div>';
            echo '</section>';
        } else {
            echo '<p>Producto no encontrado.</p>';
        }
    }

    public function mostrarProductosPorCategoria($productos, $categoria) {
        echo '<br><br><br><br>';
        echo '<section id="collection" class="py-5">';
        echo '<div class="container">';
        echo '<div class="title text-center">';
        echo '<h1>' . htmlspecialchars($categoria) . '</h1>'; // Título de la categoría
        echo '</div>';
        echo '<div class="row g-0 collection-list mt-4 gx-0 gy-3">';

        foreach ($productos as $producto) {
            // Aquí mostrar los productos con el mismo formato que en tu código actual
            echo '<div class="col-md-6 col-lg-4 col-xl-3 p-2">';
            echo '<div class="collection-img position-relative">';
            echo '<img src="' . htmlspecialchars($producto["imagen"]) . '" class="w-100">';
            echo '</div>';
            echo '<div class="text-center">';
            echo '<p class="text-capitalize my-1">' . htmlspecialchars($producto["nombre"]) . '</p>';
            echo '<span class="fw-bold">$ ' . number_format($producto["precio"], 0, ',', '.') . ' </span>';
            echo '<div class="mt-3 d-flex justify-content-between">';
            echo '<form action="carrito.php" method="post">';
            echo '<input type="hidden" name="id_producto" value="' . $producto["id_producto"] . '">';
            echo '<input type="hidden" name="accion" value="agregarCarrito">';
            echo '<button type="submit" class="btn btn-primary">Añadir al carrito</button>';
            echo '</form>';
            echo '<a href="producto.php?nombre=' . urlencode($producto["nombre"]) . '" class="btn btn-primary">Ver Detalles</a>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }

        echo '</div>';
        echo '</div>';
        echo '</section>';
    }

    public function mostrarProductosDestacados($productos) {
        // Inicio de la sección de colección
        echo '<section id="collection" class="py-5">';
        echo '<div class="container">';
        echo '<div class="title text-center">';
        echo '<br>','<br>','<br>';
        echo '<h2 class="position-relative d-inline-block">Lo último</h2>';
        echo '</div>';
    
        echo '<div class="row g-0">';
        echo '<div class="d-flex flex-wrap justify-content-center mt-5 filter-button-group">';
    
        // Botones de filtro
        echo '<button type="button" class="btn m-2 text-dark active-filter-btn" data-filter="*">Todo</button>';
        echo '<button type="button" class="btn m-2 text-dark" data-filter=".regalo">Regalos</button>';
        echo '<button type="button" class="btn m-2 text-dark" data-filter=".tecnología">Tecnología</button>';
        echo '<button type="button" class="btn m-2 text-dark" data-filter=".consumible">Consumible</button>';
        echo '<button type="button" class="btn m-2 text-dark" data-filter=".decoración">Decoración</button>';
        echo '<button type="button" class="btn m-2 text-dark" data-filter=".papelería">Papelería</button>';
    
        echo '</div>';
    
        // Listado de productos
        echo '<div class="collection-list mt-4 row gx-0 gy-3">';
        $filtro = $_GET['filtro'] ?? '*';
        $productosMostrados = [];
    
        foreach ($productos as $producto) {
            if ($filtro != '*' && strtolower($producto["categoria"]) != $filtro) {
                continue;
            }
    
            if (!isset($productosMostrados[$producto["categoria"]]) || $productosMostrados[$producto["categoria"]] < 3) {
                // Código HTML para mostrar cada producto
                echo '<div class="col-md-6 col-lg-4 col-xl-3 p-2 ' . strtolower($producto["categoria"]) . '">';
                echo '<div class="collection-img position-relative">';
                echo '<img src="' . $producto["imagen"] . '" class="w-100">';
                echo '</div>';
                echo '<div class="text-center">';
                echo '<p class="text-capitalize my-1">' . $producto["nombre"] . '</p>';
                echo '<span class="fw-bold">$ ' . number_format($producto["precio"], 0, ',', '.') . '</span>';
                echo '<div class="mt-3 d-flex justify-content-between">';
                echo '<form action="carrito.php" method="post">';
                echo '<input type="hidden" name="id_producto" value="' . $producto["id_producto"] . '">';
                echo '<input type="hidden" name="accion" value="agregarCarrito">';
                echo '<button type="submit" class="btn btn-primary">Añadir al carrito</button>';
                echo '</form>';
                echo '<a href="producto.php?nombre=' . urlencode($producto["nombre"]) . '" class="btn btn-primary">Ver Detalles</a>';
                echo '</div>';
                echo '</div>';
                echo '</div>';
    
                $productosMostrados[$producto["categoria"]] = ($productosMostrados[$producto["categoria"]] ?? 0) + 1;
            }
        }
    
        echo '</div>';
        echo '</div>';
        echo '</section>';
    }


    public function mostrarResultadosBusqueda($productos, $terminoBusqueda) {
        echo '<br><br>';
        echo '<section id="search-results" class="py-5">';
        echo '<div class="container">';
        echo '<div class="title text-center">';
        echo '<br><br>';
        echo '<h2>Resultados de búsqueda para: "' . htmlspecialchars($terminoBusqueda) . '"</h2>';
        echo '</div>';
        echo '<div class="row g-10 search-list mt-4 gx-0 gy-3">';

        if (!empty($productos)) {
            foreach ($productos as $producto) {
                echo '<div class="col-md-6 col-lg-4 col-xl-3 p-2">';
                echo '<div class="collection-img position-relative">';
                echo '<img src="' . htmlspecialchars($producto["imagen"]) . '" class="w-100">';
                echo '</div>';
                echo '<div class="text-center">';
                echo '<p class="text-capitalize my-1">' . htmlspecialchars($producto["nombre"]) . '</p>';
                echo '<span class="fw-bold">$ ' . number_format($producto["precio"], 0, ',', '.') . ' </span>';
                echo '<div class="mt-3 d-flex justify-content-between">';
                echo '<form action="carrito.php" method="post">';
                echo '<input type="hidden" name="id_producto" value="' . $producto["id_producto"] . '">';
                echo '<input type="hidden" name="accion" value="agregarCarrito">';
                echo '<button type="submit" class="btn btn-primary">Añadir al carrito</button>';
                echo '</form>';
                echo '<a href="producto.php?nombre=' . urlencode($producto["nombre"]) . '" class="btn btn-primary">Ver Detalles</a>';
                echo '</div>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo '<p>No se encontraron productos para la búsqueda: "' . htmlspecialchars($terminoBusqueda) . '".</p>';
        }

        echo '</div>';
        echo '</div>';
        echo '</section>';
    }
}
?>
