<?php
// PedidoView.php

class PedidoView {

    public function mostrarPedidosUsuario($pedidosUsuario) {
        echo '<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Pedidos</title>';
        // Aquí incluirías tus links a CSS, scripts de JavaScript, etc.
        //include 'header.php';
        echo '</head><body><div class="container px-3 my-5 clearfix">';
        
        echo '<br><br><br><br>';
        echo '<div class="card"><div class="card-header"><h2>Pedidos Registrados</h2></div><div class="card-body">';
        if (!empty($pedidosUsuario)) {
            echo '<table class="table table-bordered"><thead><tr><th>ID Pedido</th><th>Fecha</th><th>Total</th><th>Estado</th></tr></thead><tbody>';
            foreach ($pedidosUsuario as $pedido) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($pedido['id_pedido']) . "</td>";
                echo "<td>" . htmlspecialchars($pedido['fecha']) . "</td>";
                echo "<td>$" . htmlspecialchars($pedido['total']) . "</td>";
                echo "<td>" . htmlspecialchars($pedido['estado']) . "</td>";
                echo "</tr>";
            }
            echo '</tbody></table>';
        } else {
            echo '<p>No hay pedidos para mostrar.</p>';
        }
        echo '</div></div>';
        echo '<script src="js/jquery-3.6.0.js"></script>';
        echo '<!-- isotope js -->';
        echo '<script src="https://unpkg.com/isotope-layout@3/dist/isotope.pkgd.js"></script>';
        echo '<!-- bootstrap js -->';
        echo '<script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>';
        echo  '<!-- custom js -->';
        echo '<script src="js/script.js"></script>';

        echo '</div></body></html>';
    }
}
?>
