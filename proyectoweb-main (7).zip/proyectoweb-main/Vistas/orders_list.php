<!-- Vistas/orders_list.php -->
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Pedidos</title>
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body>
    
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container-fluid">
        <a class="navbar-brand" href="AdminDashboard.php">Panel Administrador</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="AdminDashboard.php">Inicio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="orders_list.php">Pedidos</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="products_list.php">Productos</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="product_create.php">Crear publicacion</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="category_list.php">Categorias</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="category_create.php">Crear categoria</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="reports.php">Reportes</a>
                </li>
            </ul>
        </div>
        <script src="../public/js/sb-admin-2.min.js"></script>
    </div>
</nav>



    <div class="container mt-4">
        <h1 class="text-center mb-4">Listado de Pedidos</h1>
        <table class="table table-hover">
            <thead class="thead-dark">
                <tr>
                    <th>ID Pedido</th>
                    <th>Total</th>
                    <th>Fecha</th>
                    <th>Estado</th>
                    <th>Cliente</th>

                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                require_once '../Controladores/OrdersController.php';
                $orderController = new OrdersController();
                $orders = $orderController->listAllOrders();
                if (!empty($orders)) :
                    foreach ($orders as $order) : ?>
                        <tr>
                            <td><?php echo htmlspecialchars($order['id_pedido']); ?></td>
                            <td><?php echo htmlspecialchars($order['total']); ?></td>
                            <td><?php echo htmlspecialchars($order['fecha']); ?></td>
                            <td><?php echo htmlspecialchars($order['estado']); ?></td>
                            <td><?php echo htmlspecialchars($order['cliente_usuario_rut']); ?></td>

                            <td>
                                <a href="order_details.php?id=<?php echo $order['id_pedido']; ?>" class="btn btn-info btn-sm">Detalles</a>
                                <a href="order_edit.php?id=<?php echo $order['id_pedido']; ?>" class="btn btn-primary btn-sm">Editar</a>
                                <form method="post" action="order_delete.php" onsubmit="return confirm('¿Estás seguro de que deseas eliminar este pedido?');" style="display: inline;">
                                    <input type="hidden" name="id_pedido" value="<?php echo $order['id_pedido']; ?>">
                                    <input type="submit" value="Eliminar" class="btn btn-danger btn-sm">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach;
                else : ?>
                    <tr>
                        <td colspan="7">No hay pedidos para mostrar.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <script src="../js/sb-admin-2.min.js"></script>
    <script>
        function confirmDelete(orderId) {
            if (confirm('¿Estás seguro de que deseas eliminar este pedido?')) {
                window.location.href = 'order_delete.php?id=' + orderId;
            }
        }
    </script>
</body>

</html>