
<?php
session_start();
include_once '../Controladores/OrdersController.php';

// Verificación de sesión del administrador
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

$orderController = new OrdersController();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $orderId = $_POST['id_pedido'] ?? null;
    if ($orderId && $orderController->deleteOrder($orderId)) {
        // Agregar mensaje de éxito en la eliminación
        $_SESSION['message'] = "Pedido eliminado con éxito.";
    } else {
        // Agregar mensaje de error en la eliminación
        $_SESSION['error'] = "Error al eliminar el pedido.";
    }
}

header('Location: orders_list.php');
exit();

