<?php
// Asegúrate de iniciar la sesión y verificar si el usuario tiene permisos para eliminar categorías
session_start();
include_once '../Controladores/CategoriesController.php';

$categoryController = new CategoriesController();

if (isset($_GET['id'])) {
    $wasSuccessful = $categoryController->deleteCategory($_GET['id']);

    if ($wasSuccessful) {
        // Redirigir a la lista de categorías con un mensaje de éxito
        header('Location: category_list.php');
        exit();
    } else {
        // Mostrar un mensaje de error
        echo "No se puede eliminar la categoría porque hay productos asociados a ella.";

    }
} else {
    // Redirigir a la lista de categorías con un mensaje de error
    echo "ID de categoría no proporcionado.";
    exit();
}

