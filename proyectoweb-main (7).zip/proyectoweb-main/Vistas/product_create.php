<?php
session_start();
include_once '../Controladores/ProductsController.php';
include_once '../Controladores/CategoriesController.php'; // Suponiendo que tienes un controlador para las categorías
include_once '../Vistas/navbar-admin.php';

// Verificación de sesión del administrador
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

$productController = new ProductsController();
$categoryController = new CategoriesController(); // Asume que tienes un controlador que puede listar categorías
$categories = $categoryController->listAllCategories(); // Debe devolver todas las categorías

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $targetDirectory = 'images2\productos'; // Asegúrate de que esta ruta sea correcta y tenga permisos de escritura.
    $imagePath = null; // Inicializa como null si no se carga ninguna imagen.

    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] == 0) {
        $imageFileName = basename($_FILES['imagen']['name']);
        $imagePath = $targetDirectory . '/' . $imageFileName;

        // Crea el directorio si no existe
        if (!file_exists($targetDirectory)) {
            mkdir($targetDirectory, 0777, true);
        }

        // Mueve el archivo subido al directorio de destino
        if (!move_uploaded_file($_FILES['imagen']['tmp_name'], $imagePath)) {
            // Maneja el error si la imagen no se puede cargar
            $imagePath = null;
            // Agrega un mensaje de error a la sesión o maneja el error como prefieras
            $_SESSION['error_message'] = "Error al subir la imagen.";
        }
    }


    // Recoger datos del formulario
    $newProductData = [
        'nombre' => $_POST['nombre'],
        'precio' => $_POST['precio'],
        'categoria' => $_POST['categoria'], // Esto debería ser el nombre de la categoría
        'descripcion' => $_POST['descripcion'],
        'stock_critico' => $_POST['stock_critico'],
        'categoria_id_categoria' => $_POST['categoria_id_categoria'], // Esto debería ser el ID de la categoría seleccionada
        'imagen' => $imagePath, // Asumiendo que $imagePath es la ruta de la imagen
        'fecha' => $_POST['fecha'],
    ];

    $wasSuccessful = $productController->createProduct($newProductData);
    if ($wasSuccessful) {
        $_SESSION['success_message'] = "Producto creado exitosamente.";
        header('Location: products_list.php');
        exit();
    } else {
        $_SESSION['error_message'] = "Error al crear el producto.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Crear Nuevo Producto</title>
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body>
<?php  include 'AdminDashboard.php' ?>
    <div class="container mt-4">
        <h1 class="mb-4">Crear Nuevo Producto</h1>
        <form method="post" action="product_create.php" enctype="multipart/form-data">
            <div class="form-group">
                <label for="nombre">Nombre:</label>
                <input type="text" class="form-control" id="nombre" name="nombre" required>
            </div>

            <div class="form-group">
                <label for="precio">Precio:</label>
                <input type="number" class="form-control" id="precio" name="precio" required>
            </div>

            <div class="form-group">
                <label for="categoria">Categoría:</label>
                <select class="form-control" id="categoria" name="categoria" required>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['id_categoria']; ?>">
                            <?php echo $category['nombre']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="descripcion">Descripción:</label>
                <textarea class="form-control" id="descripcion" name="descripcion"></textarea>
            </div>

            <div class="form-group">
                <label for="stock_critico">Stock Crítico:</label>
                <input type="number" class="form-control" id="stock_critico" name="stock_critico" required>
            </div>

            <div class="form-group">
                <label for="imagen">Imagen:</label>
                <input type="file" class="form-control-file" id="imagen" name="imagen">
            </div>

            <div class="form-group">
                <label for="fecha">Fecha:</label>
                <input type="date" class="form-control" id="fecha" name="fecha" required>
            </div>

            <button type="submit" class="btn btn-primary">Crear Producto</button>
        </form>
        
        <!-- Incluir mensajes de éxito/error -->
        <?php if (!empty($_SESSION['success_message'])) : ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success_message']; ?>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>
        <?php if (!empty($_SESSION['error_message'])) : ?>
            <div class="alert alert-danger">
                <?php echo $_SESSION['error_message']; ?>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>
    </div>
    <script src="../js/sb-admin-2.min.js"></script>
</body>

</html>
