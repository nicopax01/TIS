
<?php
session_start();
include_once '../Controladores/OrdersController.php';
include_once '../Vistas/navbar-admin.php';

// Verificación de sesión del administrador
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

$orderController = new OrdersController();
$orderId = $_GET['id'] ?? null;
$orderDetails = $orderController->getOrderDetails($orderId);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $newStatus = $_POST['estado'] ?? '';
    $orderController->updateOrderStatus($orderId, $newStatus);
    header('Location: orders_list.php'); // Puedes añadir una variable de sesión o GET para confirmar el cambio
    exit();
}

// Si no se encuentra el pedido, redirige o muestra un error
if (!$orderDetails) {
    die("Pedido no encontrado.");
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Pedido</title>
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body>
<?php  include 'AdminDashboard.php' ?>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0 text-gray-800">Editar Estado del Pedido</h1>
            <a href="orders_list.php" class="btn btn-sm btn-secondary">Volver a la lista de pedidos</a>
        </div>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'] . '?id=' . $orderId); ?>">
            <div class="form-group">
                <label for="estado">Estado del Pedido:</label>
                <select class="form-control" name="estado" id="estado">
                    <option value="pendiente" <?php echo $orderDetails['estado'] === 'pendiente' ? 'selected' : ''; ?>>Pagado</option>
                    <option value="procesado" <?php echo $orderDetails['estado'] === 'procesado' ? 'selected' : ''; ?>>Listo para retirar</option>
                    <option value="entregado" <?php echo $orderDetails['estado'] === 'entregado' ? 'selected' : ''; ?>>Entregado</option>
                    <option value="entregado" <?php echo $orderDetails['estado'] === 'entregado' ? 'selected' : ''; ?>>Cancelado</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Actualizar Pedido</button>
        </form>
    </div>
</body>
</html>
