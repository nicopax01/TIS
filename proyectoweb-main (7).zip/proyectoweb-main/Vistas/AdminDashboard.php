<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Administrador</title>
    <link href="../css/sb-admin-2.css" rel="stylesheet">
    <!-- Asegúrate de que la ruta al CSS de Bootstrap sea correcta -->
</head>
<body>

<!-- Barra de Navegación -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container-fluid">
        <a class="navbar-brand" href="AdminDashboard.php">Panel Administrador</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="AdminDashboard.php">Inicio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="orders_list.php">Pedidos</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="products_list.php">Productos</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="product_create.php">Crear publicacion</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="category_list.php">Categorias</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="category_create.php">Crear categoria</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="reports.php">Reportes</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="../index.php">Girasol</a>
                </li>
            </ul>
        </div>
        <script src="../public/js/sb-admin-2.min.js"></script>
    </div>
</nav>



<!-- Contenido Principal -->
<div class="container mt-4">
    <h1>Bienvenido al Panel Administrador</h1>
    <p>Utiliza la barra de navegación para gestionar la tienda.</p>

    <!-- Aquí puedes agregar más widgets o información resumida -->
</div>

<!-- Incluye los JS de Bootstrap -->
<script src="../js/sb-admin-2.min.js"></script>
<!-- Asegúrate de que las rutas sean correctas según tu estructura de proyecto -->

</body>
</html>
