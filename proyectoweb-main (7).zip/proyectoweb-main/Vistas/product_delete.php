
<?php
session_start();
include_once '../Controladores/ProductsController.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

$productController = new ProductsController();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productId = $_POST['id_producto'] ?? null;
    if ($productId && $productController->deleteProduct($productId)) {
        $_SESSION['success_message'] = "Producto eliminado correctamente.";
    } else {
        $_SESSION['error_message'] = "Error al eliminar el producto.";
    }
    header('Location: products_list.php');
    exit();
}
