<?php
// Asegúrate de iniciar la sesión y verificar si el usuario tiene permisos para editar categorías
session_start();
include_once '../Controladores/CategoriesController.php';
include_once '../Vistas/navbar-admin.php';

$categoryController = new CategoriesController();
$category = null;

if (isset($_GET['id'])) {
    $category = $categoryController->getCategory($_GET['id']);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_categoria = $_POST['id_categoria'];
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];

    $wasSuccessful = $categoryController->updateCategory($id_categoria, $nombre, $descripcion);

    if ($wasSuccessful) {
        // Redirigir a la lista de categorías o mostrar un mensaje de éxito
        header('Location: category_list.php');
        exit();
    } else {
        // Mostrar un mensaje de error
        echo "Error al actualizar la categoría.";
    }
}

if (!$category) {
    // Redirigir a la lista de categorías o mostrar un mensaje de error
    echo "Categoría no encontrada.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Editar Categoría</title>
    <!-- Asegúrese de que la ruta al archivo CSS es correcta -->
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-4">
        <h1 class="mb-4">Editar Categoría</h1>
        <form method="post" action="category_edit.php">
            <input type="hidden" name="id_categoria" value="<?php echo $category['id_categoria']; ?>">

            <div class="form-group">
                <label for="nombre">Nombre:</label>
                <input type="text" class="form-control" id="nombre" name="nombre" required value="<?php echo htmlspecialchars($category['nombre']); ?>">
            </div>

            <div class="form-group">
                <label for="descripcion">Descripción:</label>
                <textarea class="form-control" id="descripcion" name="descripcion"><?php echo htmlspecialchars($category['descripcion']); ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Actualizar Categoría</button>
        </form>
    </div>
    <!-- Asegúrese de que la ruta al archivo JS es correcta -->
    <script src="../public/js/sb-admin-2.min.js"></script>
</body>

</html>
