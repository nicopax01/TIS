<?php
session_start();
include_once '../Controladores/ProductsController.php';
include_once '../Vistas/navbar-admin.php';

// Verificación de sesión del administrador
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

$productController = new ProductsController();
$products = $productController->listAllProducts();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Listado de Productos</title>
    <link href="../css/sb-admin-2.min.css" rel="stylesheet" type="text/css">>
</head>

<body>
<?php  include 'AdminDashboard.php' ?>

    <div class="container mt-4">
        <!-- Mensajes de Alerta -->
        <?php if (!empty($_SESSION['success_message'])) : ?>
            <div class="alert alert-success" role="alert">
                <?php echo $_SESSION['success_message']; ?>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>
        <?php if (!empty($_SESSION['error_message'])) : ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $_SESSION['error_message']; ?>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <h1 class="mb-4">Listado de Productos</h1>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="thead-light">
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Precio</th>
                        <th>Categoría</th>
                        <th>Cantidad</th>
                        <th>Publicado el:</th>
                        <th>Categoría</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $product) : ?>
                        <tr>
                            <td><?php echo htmlspecialchars($product['id_producto']); ?></td>
                            <td><?php echo htmlspecialchars($product['nombre']); ?></td>
                            <td><?php echo htmlspecialchars($product['precio']); ?></td>
                            <td><?php echo htmlspecialchars($product['categoria_nombre']); ?></td>
                            <td><?php echo htmlspecialchars($product['stock_critico']); ?></td>
                            <td><?php echo htmlspecialchars($product['fecha']); ?></td>
                            <td><?php echo htmlspecialchars($product['categoria_nombre']); ?></td>

                            <td>
                                <a href="product_edit.php?id=<?php echo $product['id_producto']; ?>" class="btn btn-info btn-sm">Editar</a>
                                <form method="post" action="product_delete.php" onsubmit="return confirm('¿Estás seguro de que deseas eliminar este producto?');">
                                    <input type="hidden" name="id_producto" value="<?php echo $product['id_producto']; ?>">
                                    <input type="submit" value="Eliminar" class="btn btn-danger btn-sm">
                                </form>

                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <script src="../js/sb-admin-2.min.js"></script>
</body>


</html>