<?php
session_start();
include_once '../Controladores/ProductsController.php';
include_once '../Vistas/navbar-admin.php';

// Verificación de sesión del administrador
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

$productController = new ProductsController();
$productId = $_GET['id'] ?? null;
$productDetails = $productController->getProductDetails($productId);


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $imagePath = '';
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] == 0) {
        $imagePath = 'images2\productos' . basename($_FILES['imagen']['name']);
        // Asegúrate de que la carpeta 'uploads/' exista y tenga los permisos adecuados
        if (!move_uploaded_file($_FILES['imagen']['tmp_name'], $imagePath)) {
            $imagePath = ''; // Si la carga falla, deja el camino vacío
        }
    }
    // Aquí deberías tomar los datos del formulario y llamar a una función del controlador para actualizar el producto
    // Suponiendo que tienes un método 'updateProduct' en tu controlador
    $productData = [
        'nombre' => $_POST['nombre'],
        'precio' => $_POST['precio'],
        'categoria' => $_POST['categoria'],
        'imagen' => $imagePath,
        'fecha' => $_POST['fecha'],
        'descripcion' => $_POST['descripcion'],
        'stock_critico' => $_POST['stock_critico'],
        'categoria_id_categoria' => $_POST['categoria_id_categoria'],

    ];
    $productController->updateProduct($productId, $productData);
    header('Location: products_list.php');
    exit();
}

if (!$productDetails) {
    die("Producto no encontrado.");
}

// Continúa con el formulario HTML para editar el producto
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Editar Producto</title>
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-4">
        <h1 class="mb-4">Editar Producto</h1>
        <form method="post" action="product_edit.php?id=<?php echo $productId; ?>" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="nombre">Nombre:</label>
                        <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo htmlspecialchars($productDetails['nombre']); ?>" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="precio">Precio:</label>
                        <input type="number" class="form-control" id="precio" name="precio" value="<?php echo htmlspecialchars($productDetails['precio']); ?>" required>
                    </div>
                </div>
            </div>

            <!-- Repite la estructura de row y col para los demás campos -->
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="categoria">Categoría:</label>
                        <input type="text" class="form-control" id="categoria" name="categoria" value="<?php echo htmlspecialchars($productDetails['categoria']); ?>" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="categoria_id_categoria">ID de Categoría:</label>
                        <input type="text" class="form-control" id="categoria_id_categoria" name="categoria_id_categoria" value="<?php echo htmlspecialchars($productDetails['categoria_id_categoria']); ?>" required>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label for="imagen">Imagen:</label>
                <input type="file" class="form-control-file" id="imagen" name="imagen">
            </div>

            <div class="form-group">
                <label for="fecha">Fecha:</label>
                <input type="date" class="form-control" id="fecha" name="fecha" value="<?php echo htmlspecialchars($productDetails['fecha']); ?>" required>
            </div>

            <div class="form-group">
                <label for="descripcion">Descripción:</label>
                <textarea class="form-control" id="descripcion" name="descripcion" rows="3"><?php echo htmlspecialchars($productDetails['descripcion']); ?></textarea>
            </div>

            <div class="form-group">
                <label for="stock_critico">Stock Crítico:</label>
                <input type="number" class="form-control" id="stock_critico" name="stock_critico" value="<?php echo htmlspecialchars($productDetails['stock_critico']); ?>" required>
            </div>

            <button type="submit" class="btn btn-primary">Actualizar Producto</button>
        </form>
        <a href="products_list.php" class="btn btn-link">Volver a la lista de productos</a>
    </div>
</body>

</html>