<?php
// CarritoView.php

class CarritoView {

    public function mostrarDetallesCarrito($detallesCarrito) {

       
        echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Carrito</title>';
        echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer">';
        echo '<link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">';
        echo '<link rel="stylesheet" href="css/main.css">';
        echo '<style type="text/css">body{margin-top:20px;background:#eee;}.ui-w-40{width:40px!important;height:auto;}.card{box-shadow:0 1px 15px 1px rgba(52,40,104,.08);}.ui-product-color{display:inline-block;overflow:hidden;margin:.144em;width:.875rem;height:.875rem;border-radius:10rem;-webkit-box-shadow:0 0 0 1px rgba(0,0,0,0.15) inset;box-shadow:0 0 0 1px rgba(0,0,0,0.15) inset;vertical-align:middle;}</style>';
        include 'header.php';
        echo '</head><body><div class="container px-3 my-5 clearfix"><div class="card"><div class="card-header"><br><br><h2>Carrito de compras</h2></div><div class="card-body"><div class="table-responsive"><table class="table table-bordered m-0"><thead><tr><th class="text-center py-3 px-4" style="min-width: 400px;">Nombre del producto y detalles</th><th class="text-right py-3 px-4" style="width: 100px;">Precio</th><th class="text-center py-3 px-4" style="width: 120px;">Cantidad</th><th class="text-right py-3 px-4" style="width: 100px;">Total</th><th class="text-center align-middle py-3 px-0" style="width: 40px;"><a href="#" class="shop-tooltip float-none text-light" title data-original-title="Clear cart"><i class="ino ion-md-trash"></i></a></th></tr></thead><tbody>';
        
        $totalCarrito = 0;
        
        foreach ($detallesCarrito as $detalle) {
            echo "<tr>";
            
            echo '<td class="p-4">' . htmlspecialchars($detalle['nombre']) . "</td>";
            echo '<td class="text-right font-weight-semibold align-middle p-4">$' . htmlspecialchars($detalle['precio']) . "</td>";
            //echo '<td class="align-middle p-4">' . htmlspecialchars($detalle['cantidad']) . "</td>";
            echo '<td class="align-middle p-4"><input type="number" class="form-control text-center" value="' .  htmlspecialchars($detalle['cantidad']) . '" min="1"></td>';

            $subtotal = $detalle['precio'] * $detalle['cantidad'];
            $totalCarrito += $subtotal; // Sumamos al total del carrito

            echo '<td class="text-right font-weight-semibold align-middle p-4">$' . $subtotal . '</td>';
            echo '<td class="text-center align-middle px-0">';
            echo '    <a href="eliminar_producto.php?id_producto=' . $detalle['id_producto'] . '" class="shop-tooltip close float-none text-danger" title="Eliminar producto">✖</a>';
            echo '</td>';
            echo "</tr>";
        }
        echo '</tbody></table></div><div class="d-flex flex-wrap justify-content-between align-items-center pb-4"><div class="mt-4"></div><div class="d-flex"><div class="text-right mt-4 mr-5"></div><div class="text-right mt-4"><label class="text-muted font-weight-normal m-0">Total final</label><div class="text-large"><strong>$' . $totalCarrito . '</strong></div></div></div></div><div class="float-right"><button href="carrito.html" type="button" class="btn btn-lg btn-default md-btn-flat mt-2 mr-3">Actualizar carrito</button><form action="pagar.php" method="post"><input type="hidden" name="totalCarrito" value="' . $totalCarrito . '"><button type="submit" class="btn btn-lg btn-primary mt-2">Ir a pagar</button></form></div></div></div></div></body></html>';
        
        $_SESSION['total_carrito'] = $totalCarrito;
        // Suponiendo que $usuarioRut es el RUT del usuario que inicia sesión
        //$_SESSION['cliente_usuario_rut'] = $usuarioRut;


        

        

        

        echo "</table>";
    }

}


?>
