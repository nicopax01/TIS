<?php
session_start();
include_once '../Controladores/OrdersController.php';
include_once '../Vistas/navbar-admin.php';

// Verificación de sesión del administrador
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

$orderController = new OrdersController();
$orderId = $_GET['id'] ?? null;
$orderDetails = $orderController->getOrderDetails($orderId);
$orderProducts = $orderController->getOrderProductDetails($orderId);

if (!$orderDetails) {
    die("Pedido no encontrado.");
}


?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Detalles del Pedido</title>
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body>
    <?php  include 'AdminDashboard.php' ?>
    <div class="container mt-4">
        <h1 class="mb-4">Detalles del Pedido</h1>
        <div class="card mb-3">
            <div class="card-body">
                <p class="card-text">ID del Pedido: <?php echo htmlspecialchars($orderDetails['id_pedido']); ?></p>
                <p class="card-text">Total: <?php echo htmlspecialchars($orderDetails['total']); ?></p>
                <p class="card-text">Fecha: <?php echo htmlspecialchars($orderDetails['fecha']); ?></p>
                <p class="card-text">Estado: <?php echo htmlspecialchars($orderDetails['estado']); ?></p>
                <p class="card-text">Cliente: <?php echo htmlspecialchars($orderDetails['cliente_usuario_rut']); ?></p>
                <p class="card-text">Admin: <?php echo htmlspecialchars($orderDetails['admin_usuario_rut']); ?></p>
                <!-- Agrega más detalles del pedido aquí -->
            </div>
        </div>

        <h2 class="mb-3">Productos en este Pedido</h2>
        <?php if ($orderProducts) : ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Precio</th>
                            <th>Cantidad</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orderProducts as $product) : ?>
                            <tr>
                                <td><?php echo htmlspecialchars($product['nombre']); ?></td>
                                <td><?php echo htmlspecialchars($product['precio']); ?></td>
                                <td><?php echo htmlspecialchars($product['cantidad']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else : ?>
            <p>No hay productos en este pedido.</p>
        <?php endif; ?>

        <a href="orders_list.php" class="btn btn-link">Volver a la lista de pedidos</a>
    </div>
</body>

</html>