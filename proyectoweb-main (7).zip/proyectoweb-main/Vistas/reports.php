<?php
include_once '../Controladores/ReportController.php';

$dbConnection = conectarBD(); 
$reportController = new ReportController($dbConnection);
$fechaInicio = $_GET['fechaInicio'] ?? null;
$fechaFin = $_GET['fechaFin'] ?? null;

if ($fechaInicio && $fechaFin) {
    $totalVentasPorMes = $reportController->getVentasPorFecha($fechaInicio, $fechaFin);
    
}

// Obtener los datos para los reportes
$totalClientes = $reportController->getTotalClientes();
$ventasPorFecha = $reportController->getVentasPorFecha($fechaInicio, $fechaFin);
$pedidosPorEstado = $reportController->getPedidosPorEstado();
$ingresosPorPeriodo = $reportController->getIngresosPorPeriodo('2023-01-01', '2023-12-31'); // Fechas de ejemplo
$productosMasVendidos = $reportController->getProductosMasVendidos();
$ventasPorCategoria = $reportController->getVentasPorCategoria();
$clientesMasActivos = $reportController->getClientesMasActivos();
$totalVentasPorMes = $reportController->getTotalVentasPorMes();
$productosPopulares = $reportController->getProductosPopulares();
$clientesTop = $reportController->getClientesTop();
$pedidosPorCliente = $reportController->getPedidosPorCliente();
$totalVentas = $reportController->getTotalVentas();
$productosMasVendidos = $reportController->getProductosMasVendidos();
$totalPagos = $reportController->getTotalVentas();
$reportController = new ReportController($dbConnection);





include_once 'AdminDashboard.php';
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Reportes de Ventas</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }

        .chart-container {
            position: relative;
            margin: auto;
            height: 40vh;
            width: 80vw;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .header {
            background-color: #50b3a2;
            color: #ffffff;
            padding: 10px 0;
            margin-bottom: 15px;
        }

        .header h1 {
            margin: 0;
            padding: 0 20px;
            text-align: center;
            color: #ffffff;
        }

        button {
            background-color: #50b3a2;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 4px;
            transition-duration: 0.4s;
        }

        button:hover {
            background-color: #4CAF50;
            color: white;
        }

        .button-container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: row;
        }

        .chart-container {
            display: flex;
            justify-content: center;
        }

        .chart-container canvas {
            width: 50% !important;
        }

        input[type="date"] {
            padding: 10px;
            border: none;
            border-radius: 4px;
            background-color: #f2f2f2;
            margin: 10px 0;
        }

        input[type="date"]:focus {
            outline: none;
            box-shadow: 0 0 5px #50b3a2;
        }

        .form-container {
            display: flex;
            justify-content: center;
            flex-direction: column;
            align-items: center;
        }
    </style>
</head>

<body>


    <h1>Graficos</h1>

    <!-- Aquí se insertarán los gráficos -->
    <div class="form-container">
        <form action="reports.php" method="get">
            <label for="fechaInicio">Fecha Inicio:</label>
            <input type="date" id="fechaInicio" name="fechaInicio">

            <label for="fechaFin">Fecha Fin:</label>
            <input type="date" id="fechaFin" name="fechaFin">

            <input type="submit" value="Filtrar">
        </form>
    </div>
    <div class="chart-container">
        <canvas id="ventasPorFechaChart"></canvas>
    </div>
    <div class="button-container">
        <button id="downloadButtonVentasPorFecha">Descargar gráfico de Ventas por Fecha</button>
    </div>
    <div class="chart-container">
        <canvas id="ventasPorCategoriaChart"></canvas>
    </div>
    <div class="button-container">
        <button id="downloadButtonVentasPorCategoria">Descargar gráfico de Ventas por Categoría</button>
    </div>
    <div class="chart-container">
        <canvas id="ventasPorMesChart"></canvas>
    </div>
    <div class="button-container">
        <button id="downloadButton">Descargar gráfico</button>
    </div>
    <div class="chart-container">
        <canvas id="pedidosPorClienteChart"></canvas>
    </div>
    <div class="button-container">
        <button id="downloadButtonPedidosPorCliente">Descargar gráfico de Pedidos por Cliente</button>
    </div>



    <h1>Reportes de Ventas</h1>

    <!-- Formulario para buscar ventas por fecha específica -->
    
    <form action="reports.php" method="get">
        <label for="fechaBusqueda">Seleccionar Fecha de Ventas:</label>
        <input type="date" id="fechaBusqueda" name="fechaBusqueda" required>
        <button type="submit" name="buscarVentas">Buscar Ventas</button>
    </form>
    <?php
    if (isset($_GET['buscarVentas']) && !empty($_GET['fechaBusqueda'])) {
        $fechaBusqueda = $_GET['fechaBusqueda'];
        $ventas = $reportController->getVentasPorFechaEspecifica($fechaBusqueda);

        // Inicializa el total acumulado
        $totalFinal = 0;

        // Si se encontraron ventas, muestra la tabla de resultados
        if (!empty($ventas)) {
            echo "<h2>Ventas del día " . htmlspecialchars($fechaBusqueda) . "</h2>";
            echo "<table id='ventasDelDia'>";
            echo "<tr><th>ID Pedido</th><th>Total</th><th>Fecha</th><th>Estado</th></tr>";
            foreach ($ventas as $venta) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($venta['id_pedido']) . "</td>";
                echo "<td>" . htmlspecialchars($venta['total']) . "</td>";
                echo "<td>" . htmlspecialchars($venta['fecha']) . "</td>";
                echo "<td>" . htmlspecialchars($venta['estado']) . "</td>";
                echo "</tr>";
                // Acumula el total de cada venta
                $totalFinal += $venta['total'];
            }
            // Muestra el total final después de la tabla
            echo "<tr><th colspan='3'>Total Final</th><th>" . htmlspecialchars($totalFinal) . "</th></tr>";
            echo "</table>";
            echo '<button id="descargarTablaComoImagen">Descargar Tabla venta por fecha</button>';
        } else {
            echo "<p>No se encontraron ventas para la fecha seleccionada.</p>";
        }
    }
    
    $ventasPorCategoria = $reportController->getVentasPorCategoria();

    // Inicializa el total acumulado
    $totalAcumulado = 0;

    // Si se encontraron ventas, muestra la tabla de resultados
    if (!empty($ventasPorCategoria)) {
        echo "<h2>Ventas por Categoría</h2>";
        echo "<table id='ventasCategoria'>";
        echo "<tr><th>Categoría</th><th>Total Ventas</th></tr>";
        foreach ($ventasPorCategoria as $ventaCategoria) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($ventaCategoria['categoria']) . "</td>";
            echo "<td>" . htmlspecialchars($ventaCategoria['total_ventas']) . "</td>";
            echo "</tr>";
            // Suma al total acumulado
            $totalAcumulado += $ventaCategoria['total_ventas'];
        }
        // Muestra el total acumulado al final de la tabla
        echo "<tr><th>Total Acumulado</th><th>" . htmlspecialchars($totalAcumulado) . "</th></tr>";
        echo "</table>";
        echo '<button id="descargarTablaVentaCategoria">Descargar Tabla venta por categoría</button>';
    } else {
        echo "<p>No se encontraron ventas por categoría.</p>";
    }

    ?>


    <form action="reports.php" method="get">
        <label for="mesBusqueda">Seleccionar Mes y Año:</label>
        <input type="month" id="mesBusqueda" name="mesBusqueda" required>
        <button type="submit" name="buscarVentasMes">Buscar Ventas del Mes</button>
    </form>
    <?php
    if (isset($_GET['buscarVentasMes']) && !empty($_GET['mesBusqueda'])) {
        $mesAnio = $_GET['mesBusqueda'];
        $ventasMes = $reportController->getVentasPorMes($mesAnio);

        $totalFinalMes = 0;
        if (!empty($ventasMes)) {
            echo "<h2>Ventas del Mes: " . htmlspecialchars($mesAnio) . "</h2>";
            echo "<table id='tablaVentasMes'>";
            echo "<tr><th>ID Pedido</th><th>Total</th><th>Fecha</th><th>Estado</th></tr>";
            foreach ($ventasMes as $venta) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($venta['id_pedido']) . "</td>";
                echo "<td>" . htmlspecialchars($venta['total']) . "</td>";
                echo "<td>" . htmlspecialchars($venta['fecha']) . "</td>";
                echo "<td>" . htmlspecialchars($venta['estado']) . "</td>";
                echo "</tr>";
                $totalFinalMes += $venta['total'];
            }
            echo "<tr><th colspan='3'>Total del Mes</th><th>" . htmlspecialchars($totalFinalMes) . "</th></tr>";
            echo "</table>";
            echo '<button id="descargarVentasMes">Descargar Tabla de Ventas del Mes</button>';
        } else {
            echo "<p>No se encontraron ventas para el mes seleccionado.</p>";
        }
    }
    ?>





    <h2>Clientes Principales</h2>
    <table id='tablaClientes'>
        <tr>
            <th>Cliente</th>
            <th>Número de Pedidos</th>
        </tr>
        <?php foreach ($clientesTop as $cliente) : ?>
            <tr>
                <td><?php echo htmlspecialchars($cliente['nombre']); ?></td>
                <td><?php echo htmlspecialchars($cliente['num_pedidos']); ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
    <button id="clientePrincipales">Descargar Tabla Clientes principales </button>
    <!-- Tabla de reporte para Productos Más Vendidos -->

    <h2>Productos Más Vendidos</h2>

    <table id='tablaProductosVendidos'>
        <thead>
            <tr>
                <th>Producto</th>
                <th>Unidades Vendidas</th>
                <th>Número de Ventas</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($productosMasVendidos as $producto) : ?>
                <tr>
                    <td><?php echo htmlspecialchars($producto['nombre']); ?></td>
                    <td><?php echo htmlspecialchars($producto['unidades_vendidas'] ?? 'N/A'); ?></td> 
                    <td><?php echo htmlspecialchars($producto['num_ventas'] ?? 'N/A'); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <button id="productosMasVendidos">Descargar Tabla de Productos mas vendidos</button>          

    
    <script>
        var ventasPorFecha = <?php echo json_encode($ventasPorFecha); ?>;
        var ctx = document.getElementById('ventasPorFechaChart').getContext('2d');
        var ventasPorFechaChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ventasPorFecha.map(v => v.fecha),
                datasets: [{
                    label: 'Ventas por Fecha',
                    data: ventasPorFecha.map(v => v.total_ventas),
                    backgroundColor: 'rgba(0, 123, 255, 0.5)',
                    borderColor: 'rgba(0, 123, 255, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        
        var ctxCategorias = document.getElementById('ventasPorCategoriaChart').getContext('2d');
        var ventasPorCategoriaChart = new Chart(ctxCategorias, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($ventasPorCategoria, 'categoria')); ?>,
                datasets: [{
                    label: 'Ventas por Categoría',
                    data: <?php echo json_encode(array_column($ventasPorCategoria, 'total_ventas')); ?>,
                    backgroundColor: 'rgba(255, 206, 86, 0.2)',
                    borderColor: 'rgba(255, 206, 86, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
        
        var ctx = document.getElementById('ventasPorMesChart').getContext('2d');
        var ventasPorMesChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($totalVentasPorMes, 'mes')); ?>,
                datasets: [{
                    label: 'Total de Ventas por Mes',
                    data: <?php echo json_encode(array_column($totalVentasPorMes, 'total_ventas')); ?>,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
        var pedidosData = <?php echo json_encode($pedidosPorCliente); ?>;

        var ctx = document.getElementById('pedidosPorClienteChart').getContext('2d');
        var pedidosChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: pedidosData.map(item => item.nombre),
                datasets: [{
                    label: 'Número de Pedidos',
                    data: pedidosData.map(item => item.num_pedidos),
                    backgroundColor: 'rgba(0, 123, 255, 0.5)',
                    borderColor: 'rgba(0, 123, 255, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/dom-to-image/2.6.0/dom-to-image.min.js"></script>

    <script src="https://d3js.org/d3.v6.min.js"></script>
    <script>
        d3.select('#ventasPorFechaChart')
            .selectAll('div')
            .data(ventasPorFecha)
            .enter()
            .append('div')
            .style('width', d => d.total_ventas + 'px')
            .text(d => d.fecha + ': ' + d.total_ventas);
    </script>
    <script>
        document.getElementById('downloadButton').addEventListener('click', function() {
            ventasPorMesChart.canvas.toBlob(function(blob) {
                var link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = 'ventasPorMes.png';
                link.click();
            });
        });
    </script>
    <script>
        document.getElementById('downloadButtonVentasPorFecha').addEventListener('click', function() {
            var node = document.getElementById('ventasPorFechaChart');

            domtoimage.toBlob(node)
                .then(function(blob) {
                    var link = document.createElement('a');
                    link.href = URL.createObjectURL(blob);
                    link.download = 'ventasPorFecha.png';
                    link.click();
                })
                .catch(function(error) {
                    console.error('Error al generar la imagen del gráfico', error);
                });
        });
    </script>
    <script>
        document.getElementById('downloadButtonVentasPorCategoria').addEventListener('click', function() {
            var node = document.getElementById('ventasPorCategoriaChart');

            domtoimage.toBlob(node)
                .then(function(blob) {
                    var link = document.createElement('a');
                    link.href = URL.createObjectURL(blob);
                    link.download = 'ventasPorCategoria.png';
                    link.click();
                })
                .catch(function(error) {
                    console.error('Error al generar la imagen del gráfico', error);
                });
        });
    </script>
    <script>
        document.getElementById('downloadButtonPedidosPorCliente').addEventListener('click', function() {
            var node = document.getElementById('pedidosPorClienteChart');

            domtoimage.toBlob(node)
                .then(function(blob) {
                    var link = document.createElement('a');
                    link.href = URL.createObjectURL(blob);
                    link.download = 'pedidosPorCliente.png';
                    link.click();
                })
                .catch(function(error) {
                    console.error('Error al generar la imagen del gráfico', error);
                });
        });
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/dom-to-image/2.6.0/dom-to-image.min.js"></script>
    <script>
            document.getElementById('descargarVentasMes').addEventListener('click', function() {
                var node = document.getElementById('tablaVentasMes');

                domtoimage.toBlob(node)
                    .then(function(blob) {
                        var link = document.createElement('a');
                        link.href = URL.createObjectURL(blob);
                        link.download = 'ventasDelMes.png';
                        link.click();
                    })
                    .catch(function(error) {
                        console.error('Error al generar la imagen de la tabla', error);
                    });
            });

            // Repite para otros botones y tablas si es necesario
    </script>

    <script>
        document.getElementById('descargarTablaComoImagen').addEventListener('click', function() {
            var tabla = document.getElementById('ventasDelDia');
            domtoimage.toBlob(tabla)
                .then(function(blob) {
                    var link = document.createElement('a');
                    link.href = URL.createObjectURL(blob);
                    link.download = 'ventas-del-dia.png';
                    link.click();
                })
                .catch(function(error) {
                    console.error('Error al generar la imagen de la tabla', error);
                });
        });
    </script>

    <script>
        document.getElementById('descargarTablaVentaCategoria').addEventListener('click', function() {
            var tabla = document.getElementById('ventasCategoria');
            domtoimage.toBlob(tabla)
                .then(function(blob) {
                    var link = document.createElement('a');
                    link.href = URL.createObjectURL(blob);
                    link.download = 'ventasCategoría';
                    link.click();
                })
                .catch(function(error) {
                    console.error('Error al generar la imagen de la tabla', error);
                });
        });
    </script>

    <script>
        document.getElementById('clientePrincipales').addEventListener('click', function() {
            var tabla = document.getElementById('tablaClientes');
            domtoimage.toBlob(tabla)
                .then(function(blob) {
                    var link = document.createElement('a');
                    link.href = URL.createObjectURL(blob);
                    link.download = 'clientesPrincipales';
                    link.click();
                })
                .catch(function(error) {
                    console.error('Error al generar la imagen de la tabla', error);
                });
        });
    </script>


    <script>
        document.getElementById('productosMasVendidos').addEventListener('click', function() {
            var tabla = document.getElementById('tablaProductosVendidos');
            domtoimage.toBlob(tabla)
                .then(function(blob) {
                    var link = document.createElement('a');
                    link.href = URL.createObjectURL(blob);
                    link.download = 'ProductosMasVendidos';
                    link.click();
                })
                .catch(function(error) {
                    console.error('Error al generar la imagen de la tabla', error);
                });
        });
    </script>




</body>

</html>