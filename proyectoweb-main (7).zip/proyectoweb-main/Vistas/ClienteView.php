<?php
class ClienteView {
    public function mostrarFormularioRegistro($mensajeError = '') {
        // Inicio del HTML
        echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">';
        echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
        echo '<meta http-equiv="X-UA-Compatible" content="ie=edge">';
        echo '<link rel="stylesheet" href="css/login.css">';
        echo '<title>Formulario Registro</title></head><body>';

        // Sección del formulario
        echo '<section class="form-register"><h4>Registrate</h4>';

        // Mostrar mensaje de error si existe
        if ($mensajeError) {
            echo '<div class="error-message">' . htmlspecialchars($mensajeError) . '</div>';
        }

        // Formulario de registro
        echo '<form method="post" action="register.php">'; // Cambiado para apuntar a register.php
        echo '<input class="controls" type="text" name="nombre" id="nombre" placeholder="Ingrese su Nombre" required>';           
        echo '<input class="controls" type="text" name="apellido" id="apellido" placeholder="Ingrese su Apellido" required>';            
        echo '<input class="controls" type="text" name="rut" id="rut" placeholder="Ingrese su Rut sin guion " required>';   
        echo '<input class="controls" type="email" name="correo" id="correo" placeholder="Ingrese su Correo" required>';            
        echo '<input class="controls" type="password" name="contrasena" id="contrasena" placeholder="Ingrese su Contraseña" required>';
        echo '<input class="botons" type="submit" value="Registrar"></form>';
        echo '<p><a href="login.php">¿Ya tengo Cuenta?</a></p></section>';

        // Fin del HTML
        echo '</body></html>';
    }


    public function mostrarFormularioLogin($error = false) {
        echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta http-equiv="X-UA-Compatible" content="ie=edge"><link rel="stylesheet" href="css/login.css"><title>Inicio de Sesión</title></head><body>';

        echo '<section class="form-register">';
        echo '<form method="post" action="login.php">'; // Asegúrate de que este sea el script correcto
        echo '<h4>Inicio de Sesión</h4>';
        
        if ($error) {
            echo '<div class="error-message">Usuario o contraseña incorrectos</div>';
        }

        echo '<input class="controls" type="email" name="correo" id="correo" placeholder="Ingrese su Correo">';
        echo '<input class="controls" type="password" name="contrasena" id="contrasena" placeholder="Ingrese su Contraseña">';
        echo '<input class="botons" type="submit" value="Iniciar Sesión"></form>';
        echo '<p><a href="register.php">¿No tienes cuenta? Regístrate</a></p></section>';

        echo '</body></html>';
    }
}

?>