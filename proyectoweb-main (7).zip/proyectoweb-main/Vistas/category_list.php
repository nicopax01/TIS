<?php
// Incluye el controlador de categorías en la parte superior de tu archivo
include_once '../Controladores/CategoriesController.php';
include_once '../Vistas/navbar-admin.php';

$categoryController = new CategoriesController();
$categories = $categoryController->listAllCategories();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Listado de Categorías</title>
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body>
    <?php  include 'AdminDashboard.php' ?>
    <div class="container mt-4">
        <h1 class="mb-4">Listado de Categorías</h1>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Fecha Creación</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($categories as $category) : ?>
                        <tr>
                            <td><?php echo htmlspecialchars($category['id_categoria']); ?></td>
                            <td><?php echo htmlspecialchars($category['nombre']); ?></td>
                            <td><?php echo htmlspecialchars($category['descripcion']); ?></td>
                            <td><?php echo htmlspecialchars($category['fecha_creacion']); ?></td>
                            <td>
                                <a href="category_edit.php?id=<?php echo $category['id_categoria']; ?>" class="btn btn-primary btn-sm">Editar</a>
                                <a href="category_delete.php?id=<?php echo $category['id_categoria']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de que deseas eliminar esta categoría?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="../js/sb-admin-2.min.js"></script>
</body>

</html>