<?php
// Suponiendo que $conn es tu conexión a la base de datos


include 'config/conexion.php';
require_once 'Modelos/ClienteModel.php';
require_once 'Controladores/ClienteController.php';
require_once 'Vistas/ClienteView.php';

// Crear una instancia de la conexión a la base de datos
$conn = conectarBD();

$model = new ClienteModel($conn);
$controller = new ClienteController($model);
$view = new ClienteView();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller->autentificar();
} else {
    $error = isset($_GET['error']) ? true : false;
    $view->mostrarFormularioLogin($error);
}

?>