<!-- navbar.php -->
<?php
    
    $conn = conectarBD();

    $query = "SELECT nombre, precio, imagen FROM producto";
    $result = pg_query($conn, $query);

    $sqlCategorias = "SELECT id_categoria, nombre FROM categoria";
    $resultCategorias = pg_query($conn, $sqlCategorias);

    

    if (isset($_GET['action']) && $_GET['action'] == 'logout') {
        session_destroy();
        header("Location: " . $_SERVER['PHP_SELF']); // Redirige a la misma página
        exit();
    }

    


?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Girasol</title>
    <!-- fontawesome cdn -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- bootstrap css -->
    <link rel = "stylesheet" href = "bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <!-- custom css -->
    <link rel = "stylesheet" href = "css/main.css">
</head>
</head>
<body>



<nav class="navbar navbar-expand-lg navbar-light bg-white py-4 fixed-top">
    <div class="container">
        <a class="navbar-brand d-flex justify-content-between align-items-center order-lg-0" href="index.php">
            <img src="images2/girasol.png" alt="site icon">
            <span class="text-uppercase fw-lighter ms-2">Girasol</span>
        </a>

        <div class="order-lg-2 nav-btns">
            <form class="d-flex me-3" action="buscar.php" method="GET" autocomplete="off">
                <input class="form-control me-2" type="search" placeholder="Buscar" aria-label="Buscar" name="busqueda">
                <button class="btn btn-outline-success" type="submit"><i class="fas fa-search"></i></button>
            </form>
            
            <button type="button" class="btn position-relative">
                <a href="carrito.php"><i class="fa fa-shopping-cart"></i></a>
                <span class="position-absolute top-0 start-100 translate-middle badge bg-primary"></span>
            </button>
            
            <div class="btn-group">
                <button type="button" class="btn position-relative dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fa fa-user" aria-hidden="true"></i>
                </button>
                
                <ul class="dropdown-menu dropdown-menu-end">
                <?php
                if (isset($_SESSION['usuario'])) {
                    echo '<li><span class="dropdown-item-text">Hola, ' . htmlspecialchars($_SESSION['usuario']['nombre']) . '</span></li>';
                    if (isset($_SESSION['usuario']['esAdmin']) && $_SESSION['usuario']['esAdmin']) {
                        echo '<li><a class="dropdown-item" href="Vistas/AdminDashboard.php">Panel de Administrador</a></li>';
                    }
                    echo '<li><a class="dropdown-item" href="?action=logout">Cerrar sesión</a></li>';
                    echo '<li><a class="dropdown-item" href="ver_pedido.php">ver pedidos</a></li>';
                } else {
                    echo '<li><a class="dropdown-item" href="login.php">Iniciar sesión</a></li>';
                }
                
                ?>
                </ul>

               

            </div>

        </div>

        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse order-lg-1" id="navMenu">
            <ul class="navbar-nav mx-auto text-center">
                <li class="nav-item px-2 py-2">
                    <a class="nav-link text-uppercase text-dark" href="index.php">Inicio</a>
                </li>
                <li class="nav-item px-2 py-2">
                    <a class="nav-link text-uppercase text-dark" href="catalogo.php">Catálogo</a>
                </li>

                <?php
                if ($resultCategorias) {
                    // Iniciar la barra de navegación
                    echo '<ul class="navbar-nav mx-auto text-center">';

                    // Iterar sobre las categorías y generar los elementos de la barra de navegación
                    while ($rowCategoria = pg_fetch_assoc($resultCategorias)) {
                        $idCategoria = $rowCategoria['id_categoria'];
                        $nombreCategoria = $rowCategoria['nombre'];

                        echo '<li id="nav-' . strtolower($nombreCategoria) . '" class="nav-item px-2 py-2" data-categoria="' . $nombreCategoria . '">';
                        echo '<a class="nav-link text-uppercase text-dark" href="categoria.php?categoria=' . urlencode($nombreCategoria) . '">' . $nombreCategoria . '</a>';
                        echo '</li>';
                    }
                }    
                ?>
                
                <li class="nav-item px-2 py-2 border-0">
                    <a class="nav-link text-uppercase text-dark" href="index.php#about">Sobre nosotros</a>
                </li>
            </ul>
        </div>
        
    </div>
</nav>
