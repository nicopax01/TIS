<?php
// Suponiendo que $conn es tu conexión a la base de datos



session_start(); // Iniciar sesión si es necesario para manejar mensajes de error
include 'config/conexion.php';
require_once 'Modelos/ClienteModel.php';
require_once 'Controladores/ClienteController.php';
require_once 'Vistas/ClienteView.php';

// Crear una conexión a la base de datos
$conn = conectarBD(); // Asegúrate de que esta función esté definida y funcione correctamente

// Crear instancias de Modelo, Vista y Controlador
$modelo = new ClienteModel($conn);
$controlador = new ClienteController($modelo);
$vista = new ClienteView();


// Llamar a la función del controlador basado en la solicitud
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controlador->registrar();
} 
else {
    $vista->mostrarFormularioRegistro();
}
?>
