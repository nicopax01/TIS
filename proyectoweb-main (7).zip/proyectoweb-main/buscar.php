<?php
session_start();
require_once 'Controladores/ProductoController.php';
require_once 'Vistas/ProductoView.php';
include 'header.php';
$controller = new ProductoController();
$view = new ProductoView();

$terminoBusqueda = isset($_GET['busqueda']) ? $_GET['busqueda'] : '';
$productos = $controller->buscar($terminoBusqueda);
$view->mostrarResultadosBusqueda($productos, $terminoBusqueda);
include 'footer.php';
?>
