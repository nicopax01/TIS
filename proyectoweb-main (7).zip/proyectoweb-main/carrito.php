<?php
session_start();

require_once 'config/conexion.php';
require_once 'Modelos/carritoModel.php';
require_once 'Controladores/carritoController.php';

// Crear instancias del controlador y otros componentes necesarios
$controller = new CarritoController();

// Verificar si se hizo clic en "Añadir al carrito"
if (isset($_POST['id_producto']) && isset($_POST['accion']) && $_POST['accion'] === 'agregarCarrito') {
    $idProducto = $_POST['id_producto'];
    $controller->agregarAlCarrito($idProducto);
}

// Obtener el idCarrito de la sesión actual si está disponible
if (isset($_SESSION['id_carrito'])) {
    $idCarrito = $_SESSION['id_carrito'];
} else {
    // Si no está disponible en la sesión, debes manejar esta situación adecuadamente
    // Puedes redirigir al usuario a la página de inicio de sesión o realizar alguna otra acción
    die("El carrito no está disponible en la sesión.");
}

// Llamar a la función del controlador que maneja la obtención y visualización de los datos del carrito

$carritoController = new CarritoController();
$carritoController->mostrarDetallesCarrito($idCarrito);
include 'footer.php';
?>


