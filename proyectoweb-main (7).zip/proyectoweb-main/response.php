<?php
use Transbank\Webpay\WebpayPlus;

require_once 'vendor/autoload.php';

session_start();
$transaction = include('config/webpay-config.php');




if (isset($_SESSION['token_ws'])) {
    $tokenWs = $_SESSION['token_ws'];
    $response = $transaction->commit($tokenWs);

    if ($response->isApproved()) {
        // Transacción aprobada
        // Procesa el resultado (ej., actualizar base de datos)
        header('Location: finish.php');
        exit;
    } else {
        // Transacción rechazada o fallida
        header('Location: error.php');
        exit;
    }
} else {
    // No se encontró el token en la sesión
    header('Location: no token error.php');
    exit;
}
?>
